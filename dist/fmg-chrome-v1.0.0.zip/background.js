/******/ (() => { // webpackBootstrap
/******/ 	"use strict";
/******/ 	var __webpack_modules__ = ({

/***/ 48:
/***/ (function() {


var __awaiter = (this && this.__awaiter) || function (thisArg, _arguments, P, generator) {
    function adopt(value) { return value instanceof P ? value : new P(function (resolve) { resolve(value); }); }
    return new (P || (P = Promise))(function (resolve, reject) {
        function fulfilled(value) { try { step(generator.next(value)); } catch (e) { reject(e); } }
        function rejected(value) { try { step(generator["throw"](value)); } catch (e) { reject(e); } }
        function step(result) { result.done ? resolve(result.value) : adopt(result.value).then(fulfilled, rejected); }
        step((generator = generator.apply(thisArg, _arguments || [])).next());
    });
};
const RETRY_TIME_INTERVAL_MS = 500;
function checkErrors() {
    // const lastError = chrome.runtime.lastError;
    // if (lastError) {
    //     console.log("Error: ", lastError);
    // }
}
function connectToWebSocket(port) {
    return __awaiter(this, void 0, void 0, function* () {
        return new Promise((resolve, reject) => __awaiter(this, void 0, void 0, function* () {
            try {
                const ws = new WebSocket(`ws://localhost:${port}/ws`);
                ws.onopen = function () {
                    console.log(`Connected to websocket ws://localhost:${port}/ws`);
                };
                ws.onmessage = function (webSocketMessage) {
                    const messageObject = JSON.parse(webSocketMessage.data);
                    const message = messageObject.message;
                    // const data = messageObject.data;
                    switch (message) {
                        case "reload":
                            const action = "reload_window";
                            // console.log("Reload tabs");
                            chrome.tabs.query({}, function (tabs) {
                                Promise.all(tabs.map(tab => {
                                    return new Promise(resolve => {
                                        if (tab.id) {
                                            chrome.tabs.sendMessage(tab.id, { action }, () => {
                                                checkErrors();
                                                resolve(void 0);
                                            });
                                        }
                                        else {
                                            resolve(void 0);
                                        }
                                    }); //
                                }))
                                    .then(() => {
                                    // console.log("Reload extension");
                                    chrome.runtime.reload();
                                });
                            });
                            break;
                    }
                };
                ws.onclose = () => connectToWebSocket(port);
                resolve(ws);
            }
            catch (e) {
                reject();
                setTimeout(() => connectToWebSocket(port), RETRY_TIME_INTERVAL_MS);
            }
        }));
    });
}
fetch(chrome.runtime.getURL("settings.json"))
    .then(res => res.json())
    .then(settings => {
    if (settings.debug && settings.watch) {
        console.log("MapGenieProUnlock running in dev mode.");
        connectToWebSocket(settings.wss.port).then();
    }
});


/***/ })

/******/ 	});
/************************************************************************/
/******/ 	
/******/ 	// startup
/******/ 	// Load entry module and return exports
/******/ 	// This entry module is referenced by other modules so it can't be inlined
/******/ 	var __webpack_exports__ = {};
/******/ 	__webpack_modules__[48]();
/******/ 	
/******/ })()
;