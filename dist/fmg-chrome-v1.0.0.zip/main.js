/******/ (() => { // webpackBootstrap
/******/ 	"use strict";
/******/ 	var __webpack_modules__ = ({

/***/ 47:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "handleRequest": () => (/* binding */ handleRequest),
/* harmony export */   "handlers": () => (/* binding */ handlers)
/* harmony export */ });
/* harmony import */ var _page_site__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(5);
var __awaiter = (undefined && undefined.__awaiter) || function (thisArg, _arguments, P, generator) {
    function adopt(value) { return value instanceof P ? value : new P(function (resolve) { resolve(value); }); }
    return new (P || (P = Promise))(function (resolve, reject) {
        function fulfilled(value) { try { step(generator.next(value)); } catch (e) { reject(e); } }
        function rejected(value) { try { step(generator["throw"](value)); } catch (e) { reject(e); } }
        function step(result) { result.done ? resolve(result.value) : adopt(result.value).then(fulfilled, rejected); }
        step((generator = generator.apply(thisArg, _arguments || [])).next());
    });
};

function error(message) {
    window.postMessage({ type: "mg:error", message }, "*");
}
function get_status(sendResponse) {
    Promise.resolve()
        .then(() => __awaiter(this, void 0, void 0, function* () {
        sendResponse({
            is_list: yield (0,_page_site__WEBPACK_IMPORTED_MODULE_0__.isList)(),
            is_map: yield (0,_page_site__WEBPACK_IMPORTED_MODULE_0__.isMap)(),
            is_guide: yield (0,_page_site__WEBPACK_IMPORTED_MODULE_0__.isGuide)(),
        });
    }));
    return true;
}
function reload_window(sendResponse) {
    Promise.resolve()
        .then(() => __awaiter(this, void 0, void 0, function* () {
        switch (yield (0,_page_site__WEBPACK_IMPORTED_MODULE_0__["default"])()) {
            case "none":
                break;
            default:
                window.location.reload();
                break;
        }
        sendResponse();
    }));
    return true;
}
function export_mapdata(sendResponse) {
    window.postMessage({ type: "fmg:map:export" });
    return false;
}
function import_mapdata(sendResponse) {
    window.postMessage({ type: "fmg:map:import" });
    return false;
}
function clear_mapdata(sendResponse) {
    window.postMessage({ type: "fmg:map:clear" });
    return false;
}
const handlers = {
    get_status,
    reload_window,
    export_mapdata,
    import_mapdata,
    clear_mapdata
};
function handleRequest(request, _, sendResponse) {
    const action = handlers[request.action];
    if (action)
        return action(sendResponse);
    console.warn("Extension can't handle request ", request);
    return false;
}


/***/ }),

/***/ 46:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "getScript": () => (/* binding */ getScript)
/* harmony export */ });
function getScript({ startsWith, src, match }) {
    return new Promise((resolve, reject) => {
        function clear() {
            document.removeEventListener("DOMContentLoaded", loaded);
            observer.disconnect();
        }
        function loaded() {
            resolve(null);
            clear();
        }
        const observer = new MutationObserver(function (mutations_list) {
            mutations_list.forEach(function (mutation) {
                mutation.addedNodes.forEach(function (node) {
                    const script = node.nodeName === "SCRIPT" ? node : null;
                    if (script) {
                        const isCorretScript =  false
                            || startsWith && script.innerText.startsWith(startsWith)
                            || src && script.src.match(src)
                            || match && script.innerText.match(match);
                        if (isCorretScript) {
                            resolve(script);
                            clear();
                        }
                    }
                });
            });
        });
        document.addEventListener("DOMContentLoaded", loaded);
        observer.observe(document, { childList: true, subtree: true });
    });
}


/***/ }),

/***/ 5:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (/* binding */ type),
/* harmony export */   "isGuide": () => (/* binding */ isGuide),
/* harmony export */   "isList": () => (/* binding */ isList),
/* harmony export */   "isMap": () => (/* binding */ isMap)
/* harmony export */ });
/* harmony import */ var _shared_load_utils__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(6);
var __awaiter = (undefined && undefined.__awaiter) || function (thisArg, _arguments, P, generator) {
    function adopt(value) { return value instanceof P ? value : new P(function (resolve) { resolve(value); }); }
    return new (P || (P = Promise))(function (resolve, reject) {
        function fulfilled(value) { try { step(generator.next(value)); } catch (e) { reject(e); } }
        function rejected(value) { try { step(generator["throw"](value)); } catch (e) { reject(e); } }
        function step(result) { result.done ? resolve(result.value) : adopt(result.value).then(fulfilled, rejected); }
        step((generator = generator.apply(thisArg, _arguments || [])).next());
    });
};

function hasClasses(classList, ...classes) {
    for (const classString of classes) {
        if (!classList.contains(classString))
            return false;
    }
    return true;
}
function isList() {
    return __awaiter(this, void 0, void 0, function* () {
        return window.location.origin === "https://mapgenie.io"
            && window.location.pathname === "/";
    });
}
// its still possible for other sites to be miss interpreted as a map, but for now this is my solution without hardcoding all map sites urls
function isMap() {
    return __awaiter(this, void 0, void 0, function* () {
        return (0,_shared_load_utils__WEBPACK_IMPORTED_MODULE_0__.waitForDocumentBody)()
            .then(body => hasClasses(body.classList, "map", "pogo"));
    });
}
// its still possible for other sites to be miss interpreted as a guide, but for now this is my solution without hardcoding all guide sites urls
function isGuide() {
    return __awaiter(this, void 0, void 0, function* () {
        return (0,_shared_load_utils__WEBPACK_IMPORTED_MODULE_0__.waitForDocumentBody)()
            .then(body => hasClasses(body.classList, "guide", "pogo"));
    });
}
function type() {
    return __awaiter(this, void 0, void 0, function* () {
        if (yield isMap())
            return "map";
        if (yield isGuide())
            return "guide";
        if (yield isList())
            return "list";
        return "none";
    });
}


/***/ }),

/***/ 6:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "waitForDocumentBody": () => (/* binding */ waitForDocumentBody),
/* harmony export */   "waitForDomLoaded": () => (/* binding */ waitForDomLoaded),
/* harmony export */   "waitForGlobalsLoaded": () => (/* binding */ waitForGlobalsLoaded)
/* harmony export */ });
var __awaiter = (undefined && undefined.__awaiter) || function (thisArg, _arguments, P, generator) {
    function adopt(value) { return value instanceof P ? value : new P(function (resolve) { resolve(value); }); }
    return new (P || (P = Promise))(function (resolve, reject) {
        function fulfilled(value) { try { step(generator.next(value)); } catch (e) { reject(e); } }
        function rejected(value) { try { step(generator["throw"](value)); } catch (e) { reject(e); } }
        function step(result) { result.done ? resolve(result.value) : adopt(result.value).then(fulfilled, rejected); }
        step((generator = generator.apply(thisArg, _arguments || [])).next());
    });
};
function waitForDomLoaded() {
    return __awaiter(this, void 0, void 0, function* () {
        return new Promise(resolve => {
            if (document.readyState === "complete") {
                resolve(null);
            }
            else {
                const handle = setInterval(() => {
                    if (document.readyState === "complete") {
                        clearInterval(handle);
                        resolve(null);
                    }
                }, 100);
            }
        });
    });
}
function waitForDocumentBody() {
    return __awaiter(this, void 0, void 0, function* () {
        return new Promise(resolve => {
            if (document.body) {
                resolve(document.body);
            }
            else {
                const handle = setInterval(() => {
                    if (document.body) {
                        clearInterval(handle);
                        resolve(document.body);
                    }
                }, 100);
            }
        });
    });
}
function waitForGlobalsLoaded(globalVarNames, timeout = 60 * 1000) {
    return __awaiter(this, void 0, void 0, function* () {
        function globalsLoaded() {
            for (const globalVarName of globalVarNames) {
                if (typeof window[globalVarName] === "undefined") {
                    return false;
                }
            }
            return true;
        }
        return new Promise((resolve, reject) => {
            if (globalsLoaded()) {
                resolve(void 0);
            }
            else {
                const handle = setInterval(() => {
                    if (globalsLoaded()) {
                        clearInterval(handle);
                        resolve(void 0);
                    }
                }, 100);
            }
            setTimeout(() => reject("WaitForGlobals timeout reached!"), timeout);
        });
    });
}


/***/ }),

/***/ 1:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "getOptions": () => (/* binding */ getOptions),
/* harmony export */   "getSettings": () => (/* binding */ getSettings),
/* harmony export */   "setSettings": () => (/* binding */ setSettings)
/* harmony export */ });
/* harmony import */ var _options_json__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(2);

//Gets all options
function getOptions() {
    return _options_json__WEBPACK_IMPORTED_MODULE_0__;
}
//Gets stored extension settings
function getSettings() {
    return new Promise(resolve => {
        chrome.storage.sync.get(["config"], (result) => {
            let config = Object.assign({}, ..._options_json__WEBPACK_IMPORTED_MODULE_0__.map((option) => ({ [option.name]: option.default })), result.config || {});
            //Cleanup faulty keys
            for (let key in config) {
                if (key.match(/^\d+$/)) {
                    delete config[key];
                }
            }
            setSettings(config);
            resolve(config);
        });
    });
}
//Sets stored extension settings
function setSettings(settings) {
    chrome.storage.sync.set({ config: settings });
}


/***/ }),

/***/ 2:
/***/ ((module) => {

module.exports = JSON.parse('[{"type":"checkbox","default":true,"name":"extension_enabled","label":"Extension enabled","tooltip":"Enable/Disable the extension."},{"type":"checkbox","default":false,"name":"presets_allways_enabled","label":"Allways enable presets","tooltip":"This option enables presets on all maps. Will not allways work when the extension is to slow to load."},{"type":"checkbox","default":false,"name":"total_progress_bar_legacy_mode","label":"Legacy total progress bar","tooltip":"This option sets the total progress bar back to legacy mode so all categories are counted."},{"type":"checkbox","default":true,"name":"custom_search_bar","label":"Custom Searchbar","tooltip":"This option replaces the default list search bar with a slightly larger one and uses a fuzzy search algorithm to find matches."}]');

/***/ })

/******/ 	});
/************************************************************************/
/******/ 	// The module cache
/******/ 	var __webpack_module_cache__ = {};
/******/ 	
/******/ 	// The require function
/******/ 	function __webpack_require__(moduleId) {
/******/ 		// Check if module is in cache
/******/ 		var cachedModule = __webpack_module_cache__[moduleId];
/******/ 		if (cachedModule !== undefined) {
/******/ 			return cachedModule.exports;
/******/ 		}
/******/ 		// Create a new module (and put it into the cache)
/******/ 		var module = __webpack_module_cache__[moduleId] = {
/******/ 			// no module.id needed
/******/ 			// no module.loaded needed
/******/ 			exports: {}
/******/ 		};
/******/ 	
/******/ 		// Execute the module function
/******/ 		__webpack_modules__[moduleId](module, module.exports, __webpack_require__);
/******/ 	
/******/ 		// Return the exports of the module
/******/ 		return module.exports;
/******/ 	}
/******/ 	
/************************************************************************/
/******/ 	/* webpack/runtime/define property getters */
/******/ 	(() => {
/******/ 		// define getter functions for harmony exports
/******/ 		__webpack_require__.d = (exports, definition) => {
/******/ 			for(var key in definition) {
/******/ 				if(__webpack_require__.o(definition, key) && !__webpack_require__.o(exports, key)) {
/******/ 					Object.defineProperty(exports, key, { enumerable: true, get: definition[key] });
/******/ 				}
/******/ 			}
/******/ 		};
/******/ 	})();
/******/ 	
/******/ 	/* webpack/runtime/hasOwnProperty shorthand */
/******/ 	(() => {
/******/ 		__webpack_require__.o = (obj, prop) => (Object.prototype.hasOwnProperty.call(obj, prop))
/******/ 	})();
/******/ 	
/******/ 	/* webpack/runtime/make namespace object */
/******/ 	(() => {
/******/ 		// define __esModule on exports
/******/ 		__webpack_require__.r = (exports) => {
/******/ 			if(typeof Symbol !== 'undefined' && Symbol.toStringTag) {
/******/ 				Object.defineProperty(exports, Symbol.toStringTag, { value: 'Module' });
/******/ 			}
/******/ 			Object.defineProperty(exports, '__esModule', { value: true });
/******/ 		};
/******/ 	})();
/******/ 	
/************************************************************************/
var __webpack_exports__ = {};
// This entry need to be wrapped in an IIFE because it need to be isolated against other modules in the chunk.
(() => {
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _observer__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(46);
/* harmony import */ var _handlers__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(47);
/* harmony import */ var _shared_settings__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(1);



function removeScript(script) {
    const parent = script === null || script === void 0 ? void 0 : script.parentNode;
    if (script)
        script.remove();
    return { script: script, parent: parent };
}
function appendScript({ script, parent }) {
    if (script && parent) {
        return new Promise((resolve, reject) => {
            parent.append(script);
            if (script.innerText.length == 0) {
                script.onload = resolve;
                script.onerror = reject;
            }
            else {
                resolve(void 0);
            }
        });
    }
}
//Find data and map script and unparent them from the dom
const p_dataScript = Promise.race([
    (0,_observer__WEBPACK_IMPORTED_MODULE_0__.getScript)({ startsWith: "window.mapUrls" }),
    (0,_observer__WEBPACK_IMPORTED_MODULE_0__.getScript)({ startsWith: "window.mapUrl" })
]).then(removeScript);
const p_scripts = Promise.all([
    (0,_observer__WEBPACK_IMPORTED_MODULE_0__.getScript)({ src: "map.js" }),
    (0,_observer__WEBPACK_IMPORTED_MODULE_0__.getScript)({ match: "let baseUrl = document.head.querySelector" }),
    (0,_observer__WEBPACK_IMPORTED_MODULE_0__.getScript)({ match: "state.foundLocationsByCategory = window.foundLocationsByCategory;" }),
].map(p => p.then(removeScript)));
(0,_shared_settings__WEBPACK_IMPORTED_MODULE_2__.getSettings)().then((settings) => {
    return Promise.resolve()
        .then(() => {
        var _a;
        if (!settings.extension_enabled)
            return;
        window.sessionStorage.setItem("fmg:extension:settings", JSON.stringify(settings));
        window.sessionStorage.setItem("fmg:debug_mode", JSON.stringify(!!((_a = chrome.runtime.getManifest().version_name) === null || _a === void 0 ? void 0 : _a.match("-debug$"))));
        return Promise.resolve()
            .then(() => p_dataScript.then(appendScript))
            .then(() => {
            return new Promise((resolve, reject) => {
                let script = document.createElement("script");
                script.src = chrome.runtime.getURL("page.js");
                script.onload = resolve;
                script.onerror = reject;
                (document.head || document).append(script);
            });
        })
            .then(() => p_scripts.then(scripts => scripts.forEach(appendScript)));
    })
        .catch(console.error)
        .finally(() => {
        // if anything wrong happend make sure we append back the scripts
        p_dataScript.then(appendScript);
        p_scripts.then(scripts => scripts.forEach(appendScript));
    });
});
//Handle requests from popup
chrome.runtime.onMessage.addListener(_handlers__WEBPACK_IMPORTED_MODULE_1__.handleRequest);

})();

/******/ })()
;