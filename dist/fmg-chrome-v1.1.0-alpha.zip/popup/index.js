/******/ (() => { // webpackBootstrap
/******/ 	"use strict";
/******/ 	var __webpack_modules__ = ([
/* 0 */,
/* 1 */
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "getOptions": () => (/* binding */ getOptions),
/* harmony export */   "getSettings": () => (/* binding */ getSettings),
/* harmony export */   "setSettings": () => (/* binding */ setSettings)
/* harmony export */ });
/* harmony import */ var _options_json__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(2);

//Gets all options
function getOptions() {
    return _options_json__WEBPACK_IMPORTED_MODULE_0__;
}
//Gets stored extension settings
function getSettings() {
    return new Promise(resolve => {
        chrome.storage.sync.get(["config"], (result) => {
            let config = Object.assign({}, ..._options_json__WEBPACK_IMPORTED_MODULE_0__.map((option) => ({ [option.name]: option.default })), result.config || {});
            //Cleanup faulty keys
            for (let key in config) {
                if (key.match(/^\d+$/)) {
                    delete config[key];
                }
            }
            setSettings(config);
            resolve(config);
        });
    });
}
//Sets stored extension settings
function setSettings(settings) {
    chrome.storage.sync.set({ config: settings });
}


/***/ }),
/* 2 */
/***/ ((module) => {

module.exports = JSON.parse('[{"type":"checkbox","default":true,"name":"extension_enabled","label":"Extension enabled","tooltip":"Enable/Disable the extension."},{"type":"checkbox","default":false,"name":"presets_allways_enabled","label":"Allways enable presets","tooltip":"This option enables presets on all maps. Will not allways work when the extension is to slow to load."},{"type":"checkbox","default":false,"name":"total_progress_bar_legacy_mode","label":"Legacy total progress bar","tooltip":"This option sets the total progress bar back to legacy mode so all categories are counted."},{"type":"checkbox","default":true,"name":"custom_search_bar","label":"Custom Searchbar","tooltip":"This option replaces the default list search bar with a slightly larger one and uses a fuzzy search algorithm to find matches."}]');

/***/ }),
/* 3 */
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (/* binding */ send)
/* harmony export */ });
function send(action, data, options = { all: false }) {
    let queryOptions = options.all && {} || { active: true, currentWindow: true };
    return new Promise((resolve) => {
        chrome.tabs.query(queryOptions, tabs => {
            Promise.all(tabs.map(tab => {
                return new Promise((resolve, reject) => {
                    chrome.tabs.sendMessage(tab.id, { action, data }, (res) => {
                        var lastError = chrome.runtime.lastError;
                        if (lastError) {
                            reject(lastError);
                        }
                        else {
                            resolve(res);
                        }
                    });
                }).catch((err) => {
                    return new Error(err);
                });
            })).then((results) => {
                if (queryOptions.active && queryOptions.currentWindow) {
                    resolve(results[0]);
                }
                resolve(results);
            });
        });
    });
}


/***/ })
/******/ 	]);
/************************************************************************/
/******/ 	// The module cache
/******/ 	var __webpack_module_cache__ = {};
/******/ 	
/******/ 	// The require function
/******/ 	function __webpack_require__(moduleId) {
/******/ 		// Check if module is in cache
/******/ 		var cachedModule = __webpack_module_cache__[moduleId];
/******/ 		if (cachedModule !== undefined) {
/******/ 			return cachedModule.exports;
/******/ 		}
/******/ 		// Create a new module (and put it into the cache)
/******/ 		var module = __webpack_module_cache__[moduleId] = {
/******/ 			// no module.id needed
/******/ 			// no module.loaded needed
/******/ 			exports: {}
/******/ 		};
/******/ 	
/******/ 		// Execute the module function
/******/ 		__webpack_modules__[moduleId](module, module.exports, __webpack_require__);
/******/ 	
/******/ 		// Return the exports of the module
/******/ 		return module.exports;
/******/ 	}
/******/ 	
/************************************************************************/
/******/ 	/* webpack/runtime/define property getters */
/******/ 	(() => {
/******/ 		// define getter functions for harmony exports
/******/ 		__webpack_require__.d = (exports, definition) => {
/******/ 			for(var key in definition) {
/******/ 				if(__webpack_require__.o(definition, key) && !__webpack_require__.o(exports, key)) {
/******/ 					Object.defineProperty(exports, key, { enumerable: true, get: definition[key] });
/******/ 				}
/******/ 			}
/******/ 		};
/******/ 	})();
/******/ 	
/******/ 	/* webpack/runtime/hasOwnProperty shorthand */
/******/ 	(() => {
/******/ 		__webpack_require__.o = (obj, prop) => (Object.prototype.hasOwnProperty.call(obj, prop))
/******/ 	})();
/******/ 	
/******/ 	/* webpack/runtime/make namespace object */
/******/ 	(() => {
/******/ 		// define __esModule on exports
/******/ 		__webpack_require__.r = (exports) => {
/******/ 			if(typeof Symbol !== 'undefined' && Symbol.toStringTag) {
/******/ 				Object.defineProperty(exports, Symbol.toStringTag, { value: 'Module' });
/******/ 			}
/******/ 			Object.defineProperty(exports, '__esModule', { value: true });
/******/ 		};
/******/ 	})();
/******/ 	
/************************************************************************/
var __webpack_exports__ = {};
// This entry need to be wrapped in an IIFE because it need to be isolated against other modules in the chunk.
(() => {
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _shared_settings__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(1);
/* harmony import */ var _send__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(3);


let Settings;
let $buttons = [];
let $optionElements = [];
let $statusElements = [];
//Reload button to reload extension when enabled in html
$(".reload-button").on("click", () => (0,_send__WEBPACK_IMPORTED_MODULE_1__["default"])("reload_window").then(() => chrome.runtime.reload()));
//Shortcut to mapgenie homepage
$(".mapgenie-button").on("click", () => chrome.tabs.create({ url: "https://mapgenie.io" }));
//Closes the extension
$(".close-button").on("click", window.close.bind(window));
//Add options
function addCheckboxOption(name, label, checked, tooltip = "") {
    const $optionElement = $(`<div class="option" type="checkbox">
        <div class="toggle-button-cover">
            <div class="button r">
                <input class="checkbox" type="checkbox" id=${name}>
                <div class="knobs"></div>
                <div class="layer"></div>
            </div>
        </div>
        <span data-tooltip="${tooltip}">${label}</span>
        <i class="info fa fa-question-circle"></i>
    </div>`);
    $optionElement.find(".checkbox").prop("checked", checked).on("click", function () {
        if (!Settings)
            throw Error("Setting wasn't Initialized");
        Settings[name] = this.checked;
        (0,_shared_settings__WEBPACK_IMPORTED_MODULE_0__.setSettings)(Settings);
        chrome.storage.sync.set({ config: Settings });
    });
    const $label = $optionElement.find("span[data-tooltip]");
    $optionElement.find(".info").on("mouseover", function () {
        $label.addClass("hover");
    }).on("mouseout", function () {
        $label.removeClass("hover");
    });
    $(".options").append($optionElement);
    $optionElements.push($optionElement);
}
for (let option of (0,_shared_settings__WEBPACK_IMPORTED_MODULE_0__.getOptions)()) {
    switch (option.type) {
        case "checkbox":
            addCheckboxOption(option.name, option.label, option.default, option.tooltip);
            break;
    }
}
//Add status elements
["map", "guide"].forEach(name => {
    const $statusElement = $(`<div class="status" id="${name}">
        <div class="status-dot"></div>
        <span>${name}</span>
    </div>`);
    $(".statuses").append($statusElement);
    $statusElements.push($statusElement);
});
//Get status
(0,_send__WEBPACK_IMPORTED_MODULE_1__["default"])("get_status").then((status) => {
    // let activeCount = 0;
    for (let $statusElement of $statusElements) {
        if (status === null || status === void 0 ? void 0 : status[`is_${$statusElement.attr("id")}`]) {
            // activeCount++;
            $statusElement.addClass("active");
        }
        else {
            $statusElement.removeClass("active");
        }
    }
    for (let $btn of $buttons) {
        $btn.prop("disabled", !(status.is_map || status.is_guide));
    }
});
//Map data buttons to extract, import or clear data;
[
    ["button#export", "export_mapdata"],
    ["button#import", "import_mapdata"],
    ["button#clear", "clear_mapdata"]
].forEach(([selector, action]) => {
    $buttons.push($(selector).on("click", () => {
        (0,_send__WEBPACK_IMPORTED_MODULE_1__["default"])(action);
        window.close();
    }));
});
//Set extension info at the footer
fetch(chrome.runtime.getURL("settings.json"))
    .then(res => res.json())
    .then(settings => {
    $("#version").text(`v${chrome.runtime.getManifest().version_name}${settings.debug ? "-debug" : ""}`);
    $("#author").text(`by ${chrome.runtime.getManifest().author || "me"}`).on("click", () => {
        chrome.tabs.create({ url: "https://github.com/V1P3R-FMG/free-mapgenie-pro" });
    });
});
(0,_shared_settings__WEBPACK_IMPORTED_MODULE_0__.getSettings)().then(settings => {
    Settings = settings;
    for (let $optionElement of $optionElements) {
        let type = $optionElement.attr("type");
        if (type === "checkbox") {
            let $input = $optionElement.find("input");
            $input.prop("checked", settings[$input.attr("id")]);
        }
    }
});

})();

/******/ })()
;