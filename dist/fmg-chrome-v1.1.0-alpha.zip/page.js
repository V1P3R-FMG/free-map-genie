/******/ (() => { // webpackBootstrap
/******/ 	"use strict";
/******/ 	var __webpack_modules__ = ([
/* 0 */,
/* 1 */,
/* 2 */,
/* 3 */,
/* 4 */,
/* 5 */
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (/* binding */ type),
/* harmony export */   "isGuide": () => (/* binding */ isGuide),
/* harmony export */   "isList": () => (/* binding */ isList),
/* harmony export */   "isMap": () => (/* binding */ isMap)
/* harmony export */ });
/* harmony import */ var _shared_load_utils__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(6);
var __awaiter = (undefined && undefined.__awaiter) || function (thisArg, _arguments, P, generator) {
    function adopt(value) { return value instanceof P ? value : new P(function (resolve) { resolve(value); }); }
    return new (P || (P = Promise))(function (resolve, reject) {
        function fulfilled(value) { try { step(generator.next(value)); } catch (e) { reject(e); } }
        function rejected(value) { try { step(generator["throw"](value)); } catch (e) { reject(e); } }
        function step(result) { result.done ? resolve(result.value) : adopt(result.value).then(fulfilled, rejected); }
        step((generator = generator.apply(thisArg, _arguments || [])).next());
    });
};

function hasClasses(classList, ...classes) {
    for (const classString of classes) {
        if (!classList.contains(classString))
            return false;
    }
    return true;
}
function isList() {
    return __awaiter(this, void 0, void 0, function* () {
        return window.location.origin === "https://mapgenie.io"
            && window.location.pathname === "/";
    });
}
// its still possible for other sites to be miss interpreted as a map, but for now this is my solution without hardcoding all map sites urls
function isMap() {
    return __awaiter(this, void 0, void 0, function* () {
        return (0,_shared_load_utils__WEBPACK_IMPORTED_MODULE_0__.waitForDocumentBody)()
            .then(body => hasClasses(body.classList, "map", "pogo"));
    });
}
// its still possible for other sites to be miss interpreted as a guide, but for now this is my solution without hardcoding all guide sites urls
function isGuide() {
    return __awaiter(this, void 0, void 0, function* () {
        return (0,_shared_load_utils__WEBPACK_IMPORTED_MODULE_0__.waitForDocumentBody)()
            .then(body => hasClasses(body.classList, "guide", "pogo"));
    });
}
function type() {
    return __awaiter(this, void 0, void 0, function* () {
        if (yield isMap())
            return "map";
        if (yield isGuide())
            return "guide";
        if (yield isList())
            return "list";
        return "none";
    });
}


/***/ }),
/* 6 */
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "waitForDocumentBody": () => (/* binding */ waitForDocumentBody),
/* harmony export */   "waitForDomLoaded": () => (/* binding */ waitForDomLoaded),
/* harmony export */   "waitForGlobalsLoaded": () => (/* binding */ waitForGlobalsLoaded)
/* harmony export */ });
var __awaiter = (undefined && undefined.__awaiter) || function (thisArg, _arguments, P, generator) {
    function adopt(value) { return value instanceof P ? value : new P(function (resolve) { resolve(value); }); }
    return new (P || (P = Promise))(function (resolve, reject) {
        function fulfilled(value) { try { step(generator.next(value)); } catch (e) { reject(e); } }
        function rejected(value) { try { step(generator["throw"](value)); } catch (e) { reject(e); } }
        function step(result) { result.done ? resolve(result.value) : adopt(result.value).then(fulfilled, rejected); }
        step((generator = generator.apply(thisArg, _arguments || [])).next());
    });
};
function waitForDomLoaded() {
    return __awaiter(this, void 0, void 0, function* () {
        return new Promise(resolve => {
            if (document.readyState === "complete") {
                resolve(null);
            }
            else {
                const handle = setInterval(() => {
                    if (document.readyState === "complete") {
                        clearInterval(handle);
                        resolve(null);
                    }
                }, 100);
            }
        });
    });
}
function waitForDocumentBody() {
    return __awaiter(this, void 0, void 0, function* () {
        return new Promise(resolve => {
            if (document.body) {
                resolve(document.body);
            }
            else {
                const handle = setInterval(() => {
                    if (document.body) {
                        clearInterval(handle);
                        resolve(document.body);
                    }
                }, 100);
            }
        });
    });
}
function waitForGlobalsLoaded(globalVarNames, timeout = 60 * 1000) {
    return __awaiter(this, void 0, void 0, function* () {
        function globalsLoaded() {
            for (const globalVarName of globalVarNames) {
                if (typeof window[globalVarName] === "undefined") {
                    return false;
                }
            }
            return true;
        }
        return new Promise((resolve, reject) => {
            if (globalsLoaded()) {
                resolve(void 0);
            }
            else {
                const handle = setInterval(() => {
                    if (globalsLoaded()) {
                        clearInterval(handle);
                        resolve(void 0);
                    }
                }, 100);
            }
            setTimeout(() => reject("WaitForGlobals timeout reached!"), timeout);
        });
    });
}


/***/ }),
/* 7 */
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (".game-filter-options {\r\n    width: 75%;\r\n    justify-content: right;\r\n}\r\n\r\n#game-search-input[name=\"fmg:game_search\"] {\r\n    width: 60%;\r\n}");

/***/ }),
/* 8 */
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = ("button.mg-mark-all-control,\r\nbutton.mg-unmark-all-control {\r\n    width: 40px;\r\n    height: 40px;\r\n    box-shadow: none!important;\r\n    background-color: #fff!important;\r\n}\r\n\r\n.mg-mark-all-control .mapboxgl-ctrl-icon,\r\n.mg-unmark-all-control .mapboxgl-ctrl-icon {\r\n    background: none!important;\r\n    font-size: 24px;\r\n    padding: 7px 6px;\r\n}\r\n\r\n.progress-select-categories {\r\n    position: absolute;\r\n    right: 100%;\r\n    height: 0;\r\n    background-color: var(--body-background);\r\n    overflow: hidden;\r\n    transition: height 300ms ease-in;\r\n}\r\n\r\n.progress-select-categories.open {\r\n    height: auto;\r\n}");

/***/ }),
/* 9 */
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "MapUpdatedEvent": () => (/* binding */ MapUpdatedEvent),
/* harmony export */   "default": () => (/* binding */ FMG_Map)
/* harmony export */ });
/* harmony import */ var _shared_dataHandler__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(10);
/* harmony import */ var _shared_event_emitter__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(12);
/* harmony import */ var _map_manager__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(14);
/* harmony import */ var _ui_index__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(24);
/* harmony import */ var _filters_axios__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(29);
/* harmony import */ var _filters_storage__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(31);
/* harmony import */ var _shared_debounce__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(33);
var __awaiter = (undefined && undefined.__awaiter) || function (thisArg, _arguments, P, generator) {
    function adopt(value) { return value instanceof P ? value : new P(function (resolve) { resolve(value); }); }
    return new (P || (P = Promise))(function (resolve, reject) {
        function fulfilled(value) { try { step(generator.next(value)); } catch (e) { reject(e); } }
        function rejected(value) { try { step(generator["throw"](value)); } catch (e) { reject(e); } }
        function step(result) { result.done ? resolve(result.value) : adopt(result.value).then(fulfilled, rejected); }
        step((generator = generator.apply(thisArg, _arguments || [])).next());
    });
};







class MapUpdatedEvent extends _shared_event_emitter__WEBPACK_IMPORTED_MODULE_1__.DataEvent {
    constructor() { super("updated"); }
}
class FMG_Map extends _shared_event_emitter__WEBPACK_IMPORTED_MODULE_1__["default"] {
    constructor(window) {
        super();
        this.mapManager = new _map_manager__WEBPACK_IMPORTED_MODULE_2__["default"](window);
        this.ui = window.isMini ? new _ui_index__WEBPACK_IMPORTED_MODULE_3__.FMG_MINI_UI(this.mapManager) : new _ui_index__WEBPACK_IMPORTED_MODULE_3__.FMG_UI(this.mapManager);
        this.axiosFilter = new _filters_axios__WEBPACK_IMPORTED_MODULE_4__["default"](this.mapManager);
        this.storageFilter = new _filters_storage__WEBPACK_IMPORTED_MODULE_5__["default"](this.mapManager);
        this.dataHandler = new _shared_dataHandler__WEBPACK_IMPORTED_MODULE_0__["default"](window, this.mapManager.storage);
        const update = (0,_shared_debounce__WEBPACK_IMPORTED_MODULE_6__["default"])(() => {
            this.ui.update();
            this.emit(new MapUpdatedEvent());
        }, 150);
        const reload = (0,_shared_debounce__WEBPACK_IMPORTED_MODULE_6__["default"])(() => {
            console.log("reload");
            this.reload();
            this.emit(new MapUpdatedEvent());
        }, 150);
        this.dataHandler.on("updated", reload);
        this.mapManager.store.on("mark", update);
        this.mapManager.store.on("track", update);
        this.axiosFilter.on("block", update);
    }
    ready() {
        return __awaiter(this, void 0, void 0, function* () {
            const window = this.mapManager.window;
            yield new Promise(resolve => {
                if (window.map.loaded())
                    resolve(void 0);
                else {
                    let handle = setInterval(() => {
                        if (window.map.loaded()) {
                            clearInterval(handle);
                            resolve(void 0);
                        }
                    }, 50);
                }
            });
        });
    }
    init() {
        return __awaiter(this, void 0, void 0, function* () {
            yield this.ready();
            this.mapManager.load();
            this.ui.update();
        });
    }
    reload() {
        this.mapManager.reload();
    }
    on(name, f) { super.on(name, f); }
    ;
}


/***/ }),
/* 10 */
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "ClearEvent": () => (/* binding */ ClearEvent),
/* harmony export */   "ExportEvent": () => (/* binding */ ExportEvent),
/* harmony export */   "ImportEvent": () => (/* binding */ ImportEvent),
/* harmony export */   "UpdatedEvent": () => (/* binding */ UpdatedEvent),
/* harmony export */   "default": () => (/* binding */ FMG_DataHandler)
/* harmony export */ });
/* harmony import */ var _is_empty__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(11);
/* harmony import */ var _shared_event_emitter__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(12);
/* harmony import */ var _json_reader__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(13);



class ImportEvent extends _shared_event_emitter__WEBPACK_IMPORTED_MODULE_1__.DataEvent {
    constructor() { super("import"); }
}
class ExportEvent extends _shared_event_emitter__WEBPACK_IMPORTED_MODULE_1__.DataEvent {
    constructor() { super("export"); }
}
class ClearEvent extends _shared_event_emitter__WEBPACK_IMPORTED_MODULE_1__.DataEvent {
    constructor() { super("clear"); }
}
class UpdatedEvent extends _shared_event_emitter__WEBPACK_IMPORTED_MODULE_1__.DataEvent {
    constructor() { super("updated"); }
}
class FMG_DataHandler extends _shared_event_emitter__WEBPACK_IMPORTED_MODULE_1__["default"] {
    constructor(mapWindow, storageObject) {
        super();
        this.gameId = mapWindow.game.id;
        this.userId = mapWindow.user.id;
        this.storageObject = storageObject;
        this.jsonReader = new _json_reader__WEBPACK_IMPORTED_MODULE_2__["default"](mapWindow);
        this.gameTitle = mapWindow.game.title;
        window.addEventListener("message", (e) => {
            switch (e.data.type) {
                case "fmg:map:import":
                    this.import();
                    break;
                case "fmg:map:export":
                    this.export();
                    break;
                case "fmg:map:clear":
                    this.clear();
                    break;
            }
        });
    }
    error(message) {
        const toastr = window.toastr;
        if (toastr)
            toastr.error(message);
    }
    clear() {
        if (!confirm(`Are you sure you want to clear your map data for Game(${this.gameTitle})?`))
            return;
        this.storageObject.clear();
        this.emit(new ClearEvent());
        this.emit(new UpdatedEvent());
    }
    export() {
        const v5StorageObject = this.storageObject.v5;
        const v4StorageObject = this.storageObject.v4;
        if (!(v5StorageObject || v4StorageObject))
            return this.error("This map has no saved data");
        const json = {};
        json.version = "v5";
        json.gameId = this.gameId;
        json.userId = this.userId;
        if (!(0,_is_empty__WEBPACK_IMPORTED_MODULE_0__["default"])(v5StorageObject))
            json.storageObject = v5StorageObject;
        if (!(0,_is_empty__WEBPACK_IMPORTED_MODULE_0__["default"])(v4StorageObject))
            json.v4StorageObject = v4StorageObject;
        const url = URL.createObjectURL(new Blob([JSON.stringify(json)], {
            type: "text/plain;charset=utf-8"
        }));
        const a = $("<a>").attr({
            href: url,
            download: `fmg_game_${this.gameId}_user_${this.userId}_${new Date().toISOString()}.json`,
        })
            .appendTo(document.body)
            .get(0);
        a === null || a === void 0 ? void 0 : a.click();
        setTimeout(function () {
            a === null || a === void 0 ? void 0 : a.remove();
            window.URL.revokeObjectURL(url);
        });
        this.emit(new ExportEvent());
        this.emit(new UpdatedEvent());
    }
    import() {
        const $filebrowser = $("<input>").attr("type", "file").trigger("click");
        $filebrowser.on("change", () => {
            var _a;
            const file = (_a = $filebrowser.prop("files")) === null || _a === void 0 ? void 0 : _a[0];
            if (!file)
                return this.error("No file selected");
            this.jsonReader.readAsText(file).then(jsonObject => {
                $filebrowser.remove();
                if (jsonObject)
                    this.storageObject.import(jsonObject);
                this.emit(new ImportEvent());
                this.emit(new UpdatedEvent());
            }).catch(e => this.error(e));
        });
    }
    on(name, f) { super.on(name, f); }
}


/***/ }),
/* 11 */
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (/* binding */ isEmpty)
/* harmony export */ });
function isEmpty(obj) {
    for (const _ in obj)
        return false;
    return true;
}


/***/ }),
/* 12 */
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "DataEvent": () => (/* binding */ DataEvent),
/* harmony export */   "default": () => (/* binding */ EventEmitter)
/* harmony export */ });
class DataEvent extends Event {
    constructor(name, data) {
        super(name);
        this.data = data;
    }
}
class EventEmitter {
    constructor() {
        this._blockCount = 0;
        this.et = new EventTarget();
    }
    emit(e) {
        if (!this.isBlocked)
            this.et.dispatchEvent(e);
    }
    get isBlocked() {
        return this._blockCount > 0;
    }
    blockAll() {
        this._blockCount++;
    }
    unBlockAll() {
        this._blockCount = Math.max(this._blockCount - 1, 0);
    }
    on(name, f) {
        this.et.addEventListener(name, f);
    }
    off(name, f) {
        this.et.removeEventListener(name, f);
    }
}


/***/ }),
/* 13 */
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (/* binding */ FMG_JSONMapDataFileReader)
/* harmony export */ });
function confirmImportFromDifferentUser(userId) {
    return confirm(`This map data belongs to another user(${userId}). Are you sure you want to load it?`);
}
class FMG_JSONMapDataFileReader extends FileReader {
    constructor(window) {
        super();
        this._gameId = window.game.id;
        this._userId = window.user.id;
        this._current = Promise.resolve();
    }
    readAsText(blob, encoding) {
        this._current = this._current.then(() => new Promise((resolve, reject) => {
            this.onload = (e) => {
                var _a, _b;
                try {
                    const jsonObject = JSON.parse(((_b = (_a = e.target) === null || _a === void 0 ? void 0 : _a.result) === null || _b === void 0 ? void 0 : _b.toString()) || "{}");
                    if (typeof jsonObject !== "object")
                        return reject("JSON is not a valid JSON map data Object");
                    jsonObject.version = jsonObject.version || "v4";
                    //TODO: validate storageObject/mapdata object
                    switch (jsonObject.version) {
                        case "v4":
                            if (typeof jsonObject.mapdata !== "object")
                                return reject("JSON file doesn't contain valid map/storage data");
                            if (this._gameId != jsonObject.gameid)
                                return reject("JSON file is not for this game");
                            if (this._userId != jsonObject.userid && !confirmImportFromDifferentUser(jsonObject.userid || -1))
                                return resolve(null);
                            break;
                        case "v5":
                            if (typeof (jsonObject.storageObject || jsonObject.v4StorageObject) !== "object")
                                return reject("JSON file doesn't contain valid map/storage data");
                            if (this._gameId != jsonObject.gameId)
                                return reject("JSON file is not for this game");
                            if (this._userId != jsonObject.userId && !confirmImportFromDifferentUser(jsonObject.userId || -1))
                                return resolve(null);
                            break;
                        default:
                            return reject("JSON has not a valid version");
                    }
                    return resolve(jsonObject);
                }
                catch (e) {
                    return reject(`Invalid JSON file: ${e}`);
                }
            };
        }));
        super.readAsText(blob, encoding);
        return this._current;
    }
}


/***/ }),
/* 14 */
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (/* binding */ FMG_MapManager)
/* harmony export */ });
/* harmony import */ var _storage__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(15);
/* harmony import */ var _store_index__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(22);


function hasFilters(window) {
    return window.visibleLocations || window.visibleCategories;
}
class FMG_MapManager {
    constructor(window) {
        this.window = window;
        this.document = window.document;
        this.mapData = window.mapData;
        this.storage = new _storage__WEBPACK_IMPORTED_MODULE_0__["default"](window);
        this.store = new _store_index__WEBPACK_IMPORTED_MODULE_1__["default"](window, this.storage);
        this.settings = window.fmgSettings;
        this._mapManager = window.mapManager;
        this._store = window.store;
        window.user.hasPro = true;
        window.mapData.maxMarkedLocations = Infinity;
        this.store.reactUpdate();
    }
    load() {
        var _a, _b;
        this.reload();
        //don't load last visible categories if initial filters are set or the map is in mini mode
        if (hasFilters(this.window) || this.window.isMini)
            return;
        //remember visible categories
        if ((_a = this.storage.settings) === null || _a === void 0 ? void 0 : _a.remember_categories) {
            this.store.hideAllCategories();
            this.store.showCategories(Object.assign({}, (_b = this.storage.data) === null || _b === void 0 ? void 0 : _b.visible_categories));
            this.store.setRememberCategories(true);
        }
        else {
            this.store.setRememberCategories(false);
        }
    }
    reload() {
        var _a;
        this.reset();
        this.storage.reload();
        const data = this.storage.data;
        //locations
        for (var id in (data === null || data === void 0 ? void 0 : data.locations) || {}) {
            this.store.markLocation(id, true);
        }
        //the rest is not necessary if this map is in mini mode
        if (this.window.isMini)
            return;
        //categories
        for (var id in (data === null || data === void 0 ? void 0 : data.categories) || {}) {
            this.store.trackCategory(id, true);
        }
        //presets
        for (var id in (data === null || data === void 0 ? void 0 : data.presets) || {}) {
            const preset = (_a = data === null || data === void 0 ? void 0 : data.presets) === null || _a === void 0 ? void 0 : _a[id];
            this.store.addPreset(preset);
        }
        //presets order
        if ((data === null || data === void 0 ? void 0 : data.presets_order) && (data === null || data === void 0 ? void 0 : data.presets_order.length) > 0) {
            this.store.reorderPresets(data.presets_order);
        }
    }
    waitForMapLoaded() {
        return new Promise(resolve => {
            if (this.window.map.loaded())
                resolve(void 0);
            else {
                let handle = setInterval(() => {
                    if (this.window.map.loaded()) {
                        clearInterval(handle);
                        resolve(void 0);
                    }
                }, 50);
            }
        });
    }
    reset() {
        const state = this._store.getState();
        state.map.locations.forEach(loc => this.store.markLocation(loc.id, false));
        state.map.categoryIds.forEach(catId => this.store.trackCategory(catId, false));
    }
    setFoundLocationsShown(show) {
        if (this.store.state.user.foundLocationsCount > 0) {
            this._mapManager.setFoundLocationsShown(show);
        }
    }
    applyFilter(filter) {
        this._mapManager.applyFilter(filter);
    }
    markLocation(id, found) {
        this.storage.markLocation(id, found);
        this.store.markLocation(id, found);
    }
    trackCategory(id, track = true) {
        this.storage.trackCategory(id, track);
        this.store.trackCategory(id, track);
    }
    addPreset(preset) {
        this.storage.addPreset(preset);
        this.store.addPreset(preset);
    }
    deletePreset(presetId) {
        this.storage.deletePreset(presetId);
        this.store.deletePreset(presetId);
    }
    reorderPresets(ordering) {
        this.storage.reorderPresets(ordering);
        this.store.reorderPresets(ordering);
    }
    *iFoundLocationsIds() {
        var _a;
        for (var id in (_a = this.storage.data) === null || _a === void 0 ? void 0 : _a.locations)
            yield id;
    }
    *iTrackedCateogeriesIds() {
        var _a;
        for (var id in (_a = this.storage.data) === null || _a === void 0 ? void 0 : _a.categories)
            yield id;
    }
}


/***/ }),
/* 15 */
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (/* binding */ FMG_MapStorage)
/* harmony export */ });
/* harmony import */ var _shared_storage_object__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(16);
/* harmony import */ var _shared_key_toggle__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(21);


// function toggle(object: Dict<any, boolean>, key: any, enable?: boolean) {
//     enable = typeof enable === "undefined" ? object[key] : enable;
//     if (enable) object[key] = true;
//     else delete object[key];
// }
class FMG_MapStorage extends _shared_storage_object__WEBPACK_IMPORTED_MODULE_0__["default"] {
    constructor(window) {
        super();
        this.load(window);
        // this.window = window;
        const demoPreset = window.mapData.presets[0];
        this.hasDemoPreset = demoPreset && demoPreset.id == -1 || false;
    }
    markLocation(id, found) {
        (0,_shared_key_toggle__WEBPACK_IMPORTED_MODULE_1__["default"])(this.data.locations || {}, id, found);
    }
    trackCategory(id, track) {
        (0,_shared_key_toggle__WEBPACK_IMPORTED_MODULE_1__["default"])(this.data.categories || {}, id, track);
    }
    addPreset(preset) {
        const presets = this.data.presets || {};
        const presetsOrder = this.data.presets_order || [];
        if (presetsOrder.length == 0 && this.hasDemoPreset)
            presetsOrder.push(-1);
        presets[preset.id] = preset;
        presetsOrder.push(preset.id);
        for (var id in presets) {
            const preset = presets[id];
            preset.order = presetsOrder.indexOf(parseInt(id));
        }
    }
    deletePreset(presetId) {
        const presets = this.data.presets || {};
        const presetsOrder = this.data.presets_order || [];
        let index = presetsOrder.indexOf(parseInt(presetId));
        if (index !== -1)
            presetsOrder.splice(index, 1);
        if (presetsOrder.length == 1 && presetsOrder[0] == -1)
            presetsOrder.length = 0;
        delete presets[presetId];
        for (var id in presets) {
            const preset = presets[id];
            preset.order = presetsOrder.indexOf(parseInt(id));
        }
    }
    reorderPresets(ordering) {
        const presets = this.data.presets || {};
        if (this.data)
            this.data.presets_order = Object.assign([], ordering);
        for (var id in presets) {
            const preset = presets[id];
            preset.order = ordering.indexOf(parseInt(id));
        }
    }
}


/***/ }),
/* 16 */
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "FMG_StorageKeys": () => (/* binding */ FMG_StorageKeys),
/* harmony export */   "default": () => (/* binding */ FMG_StorageObject)
/* harmony export */ });
/* harmony import */ var _is_empty__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(11);
/* harmony import */ var _deep_copy__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(17);
/* harmony import */ var _deep_merge__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(18);
/* harmony import */ var _minimize__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(19);
/* harmony import */ var _reactive__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(20);





class FMG_StorageKeys {
    constructor(gameId, mapId, userId) {
        this.keyV5 = `mg:game_${gameId}:user_${userId}:v5`;
        this.keyV4 = `mg:game_${gameId}:user_${userId}`;
        this.keyV3Data = `mg:data:game_${gameId}`;
        this.keyV3Settings = `mg:settings:game_${gameId}`;
    }
}
function createDefaultStorageObject(maps) {
    const defaultStorageObject = {
        sharedData: {},
        mapData: {},
        settings: {}
    };
    defaultStorageObject.sharedData.locations = {};
    maps.forEach(map => {
        defaultStorageObject.mapData[map.id] = {
            categories: {},
            presets: {},
            presets_order: [],
            visible_categories: {},
        };
        defaultStorageObject.settings[map.id] = {
            remember_categories: false,
        };
    });
    return defaultStorageObject;
}
function combineData(...objects) {
    function alterMainObject(key, value) {
        objects.forEach((o) => {
            if (typeof o[key] !== "undefined") {
                if (typeof value === undefined) {
                    delete o[key];
                }
                else {
                    o[key] = value;
                }
            }
        });
    }
    return new Proxy(Object.assign({}, ...objects), {
        set(obj, key, value) {
            alterMainObject(key, value);
            obj[key] = value;
            return true;
        },
        deleteProperty(obj, key) {
            alterMainObject(key, undefined);
            delete obj[key];
            return true;
        }
    });
}
class FMG_StorageObject {
    constructor() {
        this.loaded = false;
        this._autosave = true;
    }
    load(window) {
        this.loaded = true;
        this.local = window.localStorage;
        this.mapId = window.mapData.map.id;
        this.keys = new FMG_StorageKeys(window.game.id, this.mapId, window.user.id);
        this.dfltStorageObject = createDefaultStorageObject(window.mapData.maps);
        this.reload();
        this.filterStorageDataObject(window.mapData);
    }
    set data(_) { throw new Error("the key data is readonly"); }
    get data() { return this._data || {}; }
    get settings() { return this._settings || {}; }
    set settings(_) { throw new Error("the key settings is readonly"); }
    get autosave() { return this._autosave; }
    get v5() {
        var _a;
        this.loadedCheck();
        return this.getJSON((_a = this.keys) === null || _a === void 0 ? void 0 : _a.keyV5);
    }
    get v4() {
        var _a;
        this.loadedCheck();
        return this.getJSON((_a = this.keys) === null || _a === void 0 ? void 0 : _a.keyV4);
    }
    set autosave(autosave) {
        this._autosave = autosave;
        if (autosave)
            this.save();
    }
    loadedCheck() {
        if (!this.loaded)
            throw new Error("no window has been loaded yet!");
    }
    restoreV3DataObject() {
        var _a, _b, _c, _d, _e, _f;
        this.loadedCheck();
        const v3Data = this.getJSON((_a = this.keys) === null || _a === void 0 ? void 0 : _a.keyV3Data);
        // if it's empty retrun, no old versions to find
        if ((0,_is_empty__WEBPACK_IMPORTED_MODULE_0__["default"])(v3Data))
            return;
        // if it isn't empty save the data to the v4 key
        this.setJSON((_b = this.keys) === null || _b === void 0 ? void 0 : _b.keyV4, { data: v3Data });
        // remove old v3 data we don't need it anymore all stuff is transfered to v4
        (_c = this.local) === null || _c === void 0 ? void 0 : _c.removeItem((_d = this.keys) === null || _d === void 0 ? void 0 : _d.keyV3Data);
        (_e = this.local) === null || _e === void 0 ? void 0 : _e.removeItem((_f = this.keys) === null || _f === void 0 ? void 0 : _f.keyV3Settings);
    }
    restoreV4DataObject() {
        var _a, _b, _c, _d, _e;
        this.loadedCheck();
        var v4Object = this.getJSON((_a = this.keys) === null || _a === void 0 ? void 0 : _a.keyV4);
        // if allready loaded this map once before don't load it again
        if ((_b = v4Object.old_data_loaded) === null || _b === void 0 ? void 0 : _b.includes(this.mapId))
            return;
        // if it's emtpy try to to find 
        if ((0,_is_empty__WEBPACK_IMPORTED_MODULE_0__["default"])(v4Object)) {
            this.restoreV3DataObject();
            v4Object = this.getJSON((_c = this.keys) === null || _c === void 0 ? void 0 : _c.keyV4);
        }
        // if we have data save that data to the v5 key
        if (v4Object.data) {
            const oldDataLoaded = v4Object.old_data_loaded = v4Object.old_data_loaded || [];
            oldDataLoaded.push(this.mapId);
            this.setJSON((_d = this.keys) === null || _d === void 0 ? void 0 : _d.keyV4, v4Object);
            this.setJSON((_e = this.keys) === null || _e === void 0 ? void 0 : _e.keyV5, { data: v4Object.data });
        }
    }
    reload() {
        var _a, _b;
        this.loadedCheck();
        var v5Object = this.getJSON((_a = this.keys) === null || _a === void 0 ? void 0 : _a.keyV5) || {};
        // if it's empty try to find old v4 data and restore it
        if ((0,_is_empty__WEBPACK_IMPORTED_MODULE_0__["default"])(v5Object)) {
            this.restoreV4DataObject();
            v5Object = this.getJSON((_b = this.keys) === null || _b === void 0 ? void 0 : _b.keyV5);
        }
        const object = (0,_deep_merge__WEBPACK_IMPORTED_MODULE_2__["default"])((0,_deep_copy__WEBPACK_IMPORTED_MODULE_1__["default"])(this.dfltStorageObject), v5Object);
        this.object = (0,_reactive__WEBPACK_IMPORTED_MODULE_4__["default"])(object, this.saveCheck.bind(this));
        if (!this.object)
            throw Error("Somthing unexpected happend!");
        this._data = combineData(this.object.mapData[this.mapId], this.object.sharedData);
        this._settings = this.object.settings[this.mapId];
    }
    filterStorageDataObject(mapData) {
        var _a, _b, _c, _d, _e;
        this.loadedCheck();
        const categories = mapData.categories;
        //remove categories that don't belong to this map
        const dataCategories = (_a = this._data) === null || _a === void 0 ? void 0 : _a.categories;
        for (const catId in dataCategories) {
            if (!categories[catId])
                dataCategories === null || dataCategories === void 0 ? true : delete dataCategories[catId];
        }
        //remove presets that don't belong to this map
        const dataPresets = (_b = this._data) === null || _b === void 0 ? void 0 : _b.presets;
        const dataPresetsOrder = (_c = this._data) === null || _c === void 0 ? void 0 : _c.presets_order;
        for (const presetId in dataPresets) {
            for (const catId of ((_d = dataPresets[presetId]) === null || _d === void 0 ? void 0 : _d.categories) || []) {
                if (!categories[catId]) {
                    delete dataPresets[presetId];
                    dataPresetsOrder === null || dataPresetsOrder === void 0 ? void 0 : dataPresetsOrder.splice(dataPresetsOrder === null || dataPresetsOrder === void 0 ? void 0 : dataPresetsOrder.indexOf(parseInt(presetId)), 1);
                }
            }
        }
        //remove visible categories that don't belong to this map
        const dataVisibleCategories = (_e = this._data) === null || _e === void 0 ? void 0 : _e.visible_categories;
        for (const catId in dataVisibleCategories) {
            if (!categories[catId])
                dataVisibleCategories === null || dataVisibleCategories === void 0 ? true : delete dataVisibleCategories[parseInt(catId)];
        }
    }
    setJSON(key, value, defaultValue) {
        var _a, _b;
        this.loadedCheck();
        if (typeof value === "object" && typeof defaultValue === "object")
            value = (0,_minimize__WEBPACK_IMPORTED_MODULE_3__["default"])(value, defaultValue);
        else if (typeof value === "undefined" && typeof defaultValue !== "undefined")
            value = defaultValue;
        if (typeof value !== "undefined")
            (_a = this.local) === null || _a === void 0 ? void 0 : _a.setItem(key, JSON.stringify(value));
        else
            (_b = this.local) === null || _b === void 0 ? void 0 : _b.removeItem(key);
    }
    getJSON(key, backupOnFail = true) {
        var _a, _b, _c, _d;
        this.loadedCheck();
        try {
            return JSON.parse(((_a = this.local) === null || _a === void 0 ? void 0 : _a.getItem(key)) || "{}");
        }
        catch (e) {
            if (backupOnFail) {
                //Create a backup of the invalid data in case the user wants to fix it
                const invalidStorageData = (_b = this.local) === null || _b === void 0 ? void 0 : _b.getItem(key);
                if (typeof invalidStorageData === "string") {
                    const dateISOString = new Date().toISOString();
                    (_c = this.local) === null || _c === void 0 ? void 0 : _c.removeItem(key);
                    (_d = this.local) === null || _d === void 0 ? void 0 : _d.setItem(`${key}:backup:[${dateISOString}]`, invalidStorageData);
                    console.error("[LOAD ERROR]:", e);
                }
            }
        }
        return {};
    }
    save() {
        var _a;
        this.loadedCheck();
        this.setJSON((_a = this.keys) === null || _a === void 0 ? void 0 : _a.keyV5, this.object, this.dfltStorageObject);
    }
    saveCheck() {
        if (this._autosave)
            this.save();
    }
    import(jsonObject) {
        var _a, _b, _c;
        this.loadedCheck();
        switch (jsonObject.version) {
            case "v4":
                if (!(0,_is_empty__WEBPACK_IMPORTED_MODULE_0__["default"])(this.v4)) {
                    if (!confirm("MapData is not empty, Do you want to override your current MapData!")) {
                        return;
                    }
                }
                this.setJSON((_a = this.keys) === null || _a === void 0 ? void 0 : _a.keyV4, jsonObject.mapdata);
                break;
            case "v5":
                if (!(0,_is_empty__WEBPACK_IMPORTED_MODULE_0__["default"])(this.v5)) {
                    if (!confirm("MapData is not empty, Do you want to override your current MapData!")) {
                        return;
                    }
                }
                if (jsonObject.v4StorageObject)
                    this.setJSON((_b = this.keys) === null || _b === void 0 ? void 0 : _b.keyV4, jsonObject.v4StorageObject);
                if (jsonObject.storageObject)
                    this.setJSON((_c = this.keys) === null || _c === void 0 ? void 0 : _c.keyV5, jsonObject.storageObject);
                break;
            default:
                throw new Error("Invalid JSON Object");
        }
        this.reload();
    }
    clear() {
        var _a, _b;
        this.loadedCheck();
        (_a = this.local) === null || _a === void 0 ? void 0 : _a.removeItem((_b = this.keys) === null || _b === void 0 ? void 0 : _b.keyV5);
    }
}


/***/ }),
/* 17 */
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (/* binding */ deepCopy)
/* harmony export */ });
function deepCopy(o) {
    return JSON.parse(JSON.stringify(o));
}


/***/ }),
/* 18 */
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (/* binding */ deepMerge)
/* harmony export */ });
/* harmony import */ var _deep_copy__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(17);

function deepMerge(value, source) {
    function helper(value, source) {
        if (typeof value === "object" && typeof source === "object") {
            const o = Object.assign(value instanceof Array ? [] : {}, value);
            for (let key in source) {
                o[key] = helper(value[key], source[key]);
            }
            return o;
        }
        return (0,_deep_copy__WEBPACK_IMPORTED_MODULE_0__["default"])(typeof source === "undefined" ? value : source);
    }
    return helper(value, source);
}


/***/ }),
/* 19 */
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (/* binding */ minimize)
/* harmony export */ });
function minimize(data, defaultData) {
    function helper(data, defaultData) {
        switch (typeof data) {
            case "object":
                if (typeof defaultData !== "object") {
                    return data;
                }
                var o = data instanceof Array ? [] : {}, c = 0;
                for (var key in data) {
                    var val = helper(data[key], defaultData[key]);
                    if (val !== undefined) {
                        o[key] = val;
                        c++;
                    }
                }
                return c > 0 ? o : undefined;
            default:
                return data !== defaultData ? data : undefined;
        }
    }
    return helper(data, defaultData);
}


/***/ }),
/* 20 */
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (/* binding */ reactive)
/* harmony export */ });
function reactive(o, onChange) {
    function helper(o, onChange) {
        if (typeof o !== "object")
            return o;
        for (var [k, v] of Object.entries(o)) {
            o[k] = helper(v, onChange);
        }
        return new Proxy(o, {
            set(obj, key, value) {
                obj[key] = helper(value, onChange);
                onChange(obj, key, value);
                return true;
            },
            deleteProperty(obj, key) {
                delete obj[key];
                onChange(obj, key, undefined);
                return true;
            },
        });
    }
    return helper(o, onChange);
}


/***/ }),
/* 21 */
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (/* export default binding */ __WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony default export */ function __WEBPACK_DEFAULT_EXPORT__(object, key, enable) {
    if (typeof enable === "undefined") {
        enable = !object[key];
    }
    if (enable) {
        object[key] = true;
    }
    else {
        delete object[key];
    }
}


/***/ }),
/* 22 */
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "StoreMarkEvent": () => (/* binding */ StoreMarkEvent),
/* harmony export */   "StoreTrackEvent": () => (/* binding */ StoreTrackEvent),
/* harmony export */   "StoreUpdatedEvent": () => (/* binding */ StoreUpdatedEvent),
/* harmony export */   "default": () => (/* binding */ FMG_Store)
/* harmony export */ });
/* harmony import */ var _shared_event_emitter__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(12);
/* harmony import */ var _state__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(23);


class StoreMarkEvent extends _shared_event_emitter__WEBPACK_IMPORTED_MODULE_0__.DataEvent {
    constructor(id, marked) { super("mark", { id, marked }); }
}
class StoreTrackEvent extends _shared_event_emitter__WEBPACK_IMPORTED_MODULE_0__.DataEvent {
    constructor(id, tracked) { super("track", { id, tracked }); }
}
class StoreUpdatedEvent extends _shared_event_emitter__WEBPACK_IMPORTED_MODULE_0__.DataEvent {
    constructor() { super("updated"); }
}
class FMG_Store extends _shared_event_emitter__WEBPACK_IMPORTED_MODULE_0__["default"] {
    constructor(window, storage) {
        super();
        this.window = window;
        this.map = window.map;
        this.gameId = window.game.id;
        this.store = window.store;
        this.state = new _state__WEBPACK_IMPORTED_MODULE_1__["default"](window, storage);
    }
    markLocation(id, found = true) {
        id = parseInt(id);
        this.map.setFeatureState({ source: "locations-data", id }, { found });
        if (this.gameId === 80)
            this.map.setFeatureState({ source: "circle-locations-data", id }, { found });
        this.emit(new StoreMarkEvent(id, found));
    }
    trackCategory(id, track = true) {
        let type = track ? "HIVE:USER:ADD_TRACKED_CATEGORY" : "HIVE:USER:REMOVE_TRACKED_CATEGORY";
        this.store.dispatch({ type, meta: { categoryId: parseInt(id) } });
        this.emit(new StoreTrackEvent(id, track));
    }
    addPreset(preset) {
        this.store.dispatch({ type: "HIVE:USER:ADD_PRESET", meta: { preset } });
    }
    deletePreset(presetId) {
        this.store.dispatch({ type: "HIVE:USER:DELETE_PRESET", meta: { presetId } });
    }
    reorderPresets(ordering) {
        let presets = [];
        for (let preset of this.state.user.presets) {
            presets[ordering.indexOf(preset.id)] = preset;
        }
    }
    showAllCategories() {
        this.store.dispatch({ type: "HIVE:MAP:SHOW_ALL_CATEGORIES" });
    }
    hideAllCategories() {
        this.store.dispatch({ type: "HIVE:MAP:HIDE_ALL_CATEGORIES" });
    }
    showCategories(visibilities) {
        this.store.dispatch({ type: "HIVE:MAP:SET_CATEGORIES_VISIBILITY", meta: { visibilities } });
    }
    setRememberCategories(remembered) {
        // console.log("set remebered!", remembered);
        const $label = $(this.window.document).find("label[for='remember-categories-checkbox']");
        const $div = $label.closest(".checkbox-wrapper");
        // console.log(!$label, $div);
        const label = $label.get(0);
        if (!label)
            return;
        const image = this.window.getComputedStyle(label, ":after").webkitMaskImage;
        const checked = image != "none" && image != "";
        // console.log(checked, !!remembered);
        if (!!remembered != checked) {
            $div.trigger("click");
        }
    }
    reactUpdate() {
        this.store.dispatch({ type: "HIVE:MAP:UPDATE_CATEGORY", meta: { category: {} } }); //Force a react update
    }
    on(name, f) { super.on(name, f); }
}


/***/ }),
/* 23 */
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (/* binding */ FMG_State)
/* harmony export */ });
class FMG_State {
    constructor(window, storage) {
        this.storage = storage;
        const categories = window.store.getState().map.categories;
        this.categoriesByTitle = {};
        for (var catId in categories) {
            const cat = categories[catId];
            this.categoriesByTitle[cat.title] = cat;
        }
        this._getState = window.store.getState;
        window.store.getState = () => {
            const state = this._getState();
            state.user = this.user;
            return state;
        };
    }
    get map() {
        const state = this._getState();
        const map = state.map;
        map.categoriesByTitle = this.categoriesByTitle;
        return map;
    }
    get user() {
        var _a;
        const state = this._getState();
        const user = state.user;
        user.foundLocations = ((_a = this.storage.data) === null || _a === void 0 ? void 0 : _a.locations) || {};
        return user;
    }
    get routes() {
        const state = this._getState();
        const routes = state.routes;
        return routes;
    }
    get editor() {
        const state = this._getState();
        const editor = state.editor;
        return editor;
    }
    get search() {
        const state = this._getState();
        const search = state.search;
        return search;
    }
}


/***/ }),
/* 24 */
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "FMG_MINI_UI": () => (/* binding */ FMG_MINI_UI),
/* harmony export */   "FMG_UI": () => (/* binding */ FMG_UI)
/* harmony export */ });
/* harmony import */ var _category_tracker__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(25);
/* harmony import */ var _mark_controls__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(26);
/* harmony import */ var _toggle_found__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(27);
/* harmony import */ var _total_progress__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(28);




class FMG_UI {
    constructor(manager) {
        this.toggleFound = new _toggle_found__WEBPACK_IMPORTED_MODULE_2__["default"](manager);
        this.categoryTracker = new _category_tracker__WEBPACK_IMPORTED_MODULE_0__["default"](manager);
        this.totalProgress = new _total_progress__WEBPACK_IMPORTED_MODULE_3__["default"](manager);
        this.markControls = new _mark_controls__WEBPACK_IMPORTED_MODULE_1__["default"](manager);
    }
    update() {
        this.toggleFound.update();
        this.categoryTracker.update();
        this.totalProgress.update();
    }
}
class FMG_MINI_UI {
    constructor(manager) {
    }
    update() {
    }
}


/***/ }),
/* 25 */
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "FMG_CategoryItem": () => (/* binding */ FMG_CategoryItem),
/* harmony export */   "default": () => (/* binding */ FMG_CategoryTracker)
/* harmony export */ });
function getCategoryNameFromItemWrapper(categoryItemWrapper) {
    return $(categoryItemWrapper).find(".title").text();
}
function isItemWrapper(element) {
    return element.classList.contains("progress-item-wrapper") && !element.classList.contains("clone");
}
class FMG_CategoryItem {
    constructor(element, categoryId, total) {
        this.$original = $(element).hide();
        this.$element = this.$original.clone().addClass("clone").insertAfter(this.$original).show();
        this.$counter = this.$element.find(".counter");
        this.$progressBar = this.$element.find(".progress-bar");
        const $originalRemoveElement = this.$original.find(".progress-item-remove");
        this.$element.find(".progress-item-remove").on("click", () => {
            $originalRemoveElement.trigger("click");
        });
        const $originalItemElement = this.$original.find(".progress-item");
        this.$element.find(".progress-item").on("click", () => {
            $originalItemElement.trigger("click");
        });
        this.catId = categoryId;
        this.total = total;
    }
    update(count) {
        this.$counter.text(`${count}/${this.total}`);
        this.$progressBar.css("width", `${count / this.total * 100}%`);
    }
    remove() {
        this.$element.remove();
    }
}
class FMG_CategoryTracker {
    constructor(manager) {
        this._manager = manager;
        this._categories = {};
        this._categoriesByTitle = manager.store.state.map.categoriesByTitle;
        this._locationsByCategrories = manager.store.state.map.locationsByCategory;
        this.$categoryProgress = $(manager.document).find(".category-progress");
        this.$categoryProgress.find(".progress-item-wrapper").each((_, element) => this._add(element));
        this._observer = new MutationObserver(mutations => {
            mutations.forEach(mutation => {
                mutation.addedNodes.forEach(node => {
                    if (isItemWrapper(node))
                        this._add(node);
                });
                mutation.removedNodes.forEach(node => {
                    if (isItemWrapper(node))
                        this._remove(node);
                });
            });
        });
        const categoryProgress = this.$categoryProgress.get(0);
        if (categoryProgress) {
            this._observer.observe(categoryProgress, {
                childList: true
            });
        }
        else {
            console.warn("No category progress element!");
        }
    }
    _add(categoryItemWrapper) {
        const title = getCategoryNameFromItemWrapper(categoryItemWrapper);
        const cat = this._categoriesByTitle[title];
        const total = this._locationsByCategrories[cat.id].length || 0;
        const catItem = new FMG_CategoryItem(categoryItemWrapper, (cat === null || cat === void 0 ? void 0 : cat.id) || -1, total);
        this._categories[cat.id] = catItem;
        catItem.update(this.calculateCategoryProgress(cat.id));
    }
    _remove(categoryItemWrapper) {
        const title = getCategoryNameFromItemWrapper(categoryItemWrapper);
        const cat = this._categoriesByTitle[title];
        const catItem = this._categories[cat.id];
        catItem === null || catItem === void 0 ? void 0 : catItem.remove();
        delete this._categories[cat.id];
    }
    calculateCategoryProgress(catId) {
        var count = 0;
        const state = this._manager.store.state;
        const locations = state.map.locationsByCategory[catId] || [];
        const data = this._manager.storage.data;
        locations.forEach(loc => {
            var _a;
            if ((_a = data === null || data === void 0 ? void 0 : data.locations) === null || _a === void 0 ? void 0 : _a[loc.id]) {
                count += 1;
            }
        });
        return count;
    }
    update() {
        for (var catId in this._categories) {
            const catItem = this._categories[catId];
            catItem === null || catItem === void 0 ? void 0 : catItem.update(this.calculateCategoryProgress(catId));
        }
    }
}


/***/ }),
/* 26 */
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (/* binding */ FMG_MarkControls)
/* harmony export */ });
class FMG_MarkControls {
    constructor(manager) {
        this.manager = manager;
        this.$element = $(`<div class="mapboxgl-ctrl mapboxgl-ctrl-group">
            <button class="mg-mark-all-control" type="button" title="Mark all" aria-label="Mark all" aria-disabled="false">
                <span class="mapboxgl-ctrl-icon ion-md-add-circle" aria-hidden="true"></span>
            </button>
            <button class="mg-unmark-all-control" type="button" title="UnMark all" aria-label="Unmark all" aria-disabled="false">
                <span class="mapboxgl-ctrl-icon ion-md-close-circle" aria-hidden="true"></span>
            </button>
        </div>`);
        this.$markAll = this.$element.find(".mg-mark-all-control");
        this.$unmarkAll = this.$element.find(".mg-unmark-all-control");
        this.$markAll.on("click", () => this.markVisibleLocations(true));
        this.$unmarkAll.on("click", () => this.markVisibleLocations(false));
        this.$element.insertAfter($(manager.window.document).find("#add-note-control"));
    }
    markVisibleLocations(found) {
        //Confirm if the user want's to unmark or mark all visible markers
        if (!confirm(`Are you sure you want to ${!found ? "un" : ""}mark all visible markers on the map?`))
            return;
        // disable autosave to pack all changes in one save instead of multiple
        this.manager.storage.autosave = false;
        const categories = this.manager.store.state.map.categories;
        for (var catId in categories) {
            const cat = categories[catId];
            if (cat.visible) {
                const locations = this.manager.store.state.map.locationsByCategory[catId] || [];
                locations.forEach(loc => this.manager.markLocation(loc.id, found));
            }
        }
        this.manager.storage.autosave = true;
    }
}


/***/ }),
/* 27 */
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (/* binding */ FMG_ToggleFound)
/* harmony export */ });
class FMG_ToggleFound {
    constructor(manager) {
        const $toggleFound = $(manager.window.document).find("#toggle-found").hide();
        this.$element = $toggleFound.clone()
            .insertAfter($toggleFound)
            .show()
            .on("click", () => {
            $toggleFound.trigger("click");
            this.$element.toggleClass("disabled", $toggleFound.hasClass("disabled"));
        });
        this._manager = manager;
    }
    calculateFoundLocations() {
        var count = 0;
        const data = this._manager.storage.data;
        const locationsById = this._manager.store.state.map.locationsById;
        for (var id in (data === null || data === void 0 ? void 0 : data.locations) || {}) {
            if (locationsById[id]) {
                count++;
            }
        }
        return count;
    }
    update() {
        this.$element.html(`
            <i class="icon ui-icon-show-hide"></i>
            Found Locations(${this.calculateFoundLocations()})
        `);
    }
}


/***/ }),
/* 28 */
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (/* binding */ FMG_TotalProgress)
/* harmony export */ });
class FMG_TotalProgress {
    constructor(manager) {
        this._manager = manager;
        this.$element = $(`<div class="progress-item-wrapper">
            <div class="progress-item" id="total-progress" style="margin-right: 5%;">
                <span class="icon">0.00%</span>
                <span class="title"></span>
                <span class="counter">0/0</span>
                <div class="progress-bar-container">
                    <div class="progress-bar" role="progressbar" style="width: 0%;"></div>
                </div>
            </div>
        </div>
        <hr>`);
        this.$item = this.$element.find(".progress-item");
        this.$icon = this.$element.find(".icon");
        this.$counter = this.$element.find(".counter");
        this.$progressBar = this.$element.find(".progress-bar");
        this.$element.insertBefore($(manager.window.document).find("#user-panel > div:first-of-type .category-progress"));
    }
    calculateTotal() {
        var count = 0;
        const data = this._manager.storage.data;
        const state = this._manager.store.state;
        for (var catId in (data === null || data === void 0 ? void 0 : data.categories) || {}) {
            const locations = state.map.locationsByCategory[catId] || [];
            count += locations.length;
        }
        return count;
    }
    calculateTotalLegacy() {
        var count = 0;
        const state = this._manager.store.state;
        state.map.categoryIds.forEach(catId => {
            const locations = state.map.locationsByCategory[catId] || [];
            count += locations.length;
        });
        return count;
    }
    calculateProgress() {
        var count = 0;
        const data = this._manager.storage.data;
        const categories = (data === null || data === void 0 ? void 0 : data.categories) || {};
        const locationsById = this._manager.store.state.map.locationsById;
        for (var locId in (data === null || data === void 0 ? void 0 : data.locations) || {}) {
            const loc = locationsById[locId];
            if (loc && categories[loc.category_id]) {
                count += 1;
            }
        }
        return count;
    }
    calculateProgressLegacy() {
        var count = 0;
        const data = this._manager.storage.data;
        const locationsById = this._manager.store.state.map.locationsById;
        for (var id in (data === null || data === void 0 ? void 0 : data.locations) || {}) {
            if (locationsById[id]) {
                count++;
            }
        }
        return count;
    }
    update() {
        var _a;
        const legacy = ((_a = this._manager.settings) === null || _a === void 0 ? void 0 : _a.total_progress_bar_legacy_mode) || false;
        const count = legacy ? this.calculateProgressLegacy() : this.calculateProgress();
        const total = legacy ? this.calculateTotalLegacy() : this.calculateTotal();
        let percent = total == 0 ? 100 : count / total * 100;
        this.$icon.text(`${percent.toFixed(2)}%`);
        this.$counter.text(`${count} / ${total}`);
        this.$progressBar.css("width", `${percent}%`);
    }
}


/***/ }),
/* 29 */
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (/* binding */ FMG_MapAxiosFilter)
/* harmony export */ });
/* harmony import */ var _shared_filters_axios__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(30);

const handleLocation = function (_, id) {
    var _a, _b;
    const isMarked = (_b = (_a = this.manager.storage.data) === null || _a === void 0 ? void 0 : _a.locations) === null || _b === void 0 ? void 0 : _b[id];
    try {
        this.manager.storage.markLocation(id, !isMarked);
    }
    catch (e) {
        console.error(e);
    }
    this.manager.store.markLocation(id, !isMarked);
};
const handleCategory = function (_, id, data) {
    var _a, _b;
    id = (data === null || data === void 0 ? void 0 : data.category) || id;
    const isTracked = (_b = (_a = this.manager.storage.data) === null || _a === void 0 ? void 0 : _a.categories) === null || _b === void 0 ? void 0 : _b[id];
    this.manager.storage.trackCategory(id, !isTracked);
    this.manager.store.trackCategory(id, !isTracked);
};
const PutHandler = {
    locations: handleLocation
};
const PostHandler = {
    presets(_, __, data) {
        var _a;
        const presets = ((_a = this.manager.storage.data) === null || _a === void 0 ? void 0 : _a.presets) || {};
        data.id = 0;
        while (presets[data.id])
            data.id++;
        this.manager.storage.addPreset({
            id: data.id,
            title: data.title,
            order: data.ordering.length - 1,
            categories: data.categories,
        });
        return { data };
    },
    presets_reorder(_, __, data) {
        this.manager.storage.reorderPresets(data.ordering);
    },
    categories: handleCategory
};
const DeleteHandler = {
    presets(_, id) {
        this.manager.storage.deletePreset(id);
    },
    locations: handleLocation,
    categories: handleCategory
};
class FMG_MapAxiosFilter extends _shared_filters_axios__WEBPACK_IMPORTED_MODULE_0__["default"] {
    constructor(manager) {
        super(manager.window.axios, {
            put: PutHandler,
            post: PostHandler,
            delete: DeleteHandler
        });
        this.manager = manager;
    }
}


/***/ }),
/* 30 */
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "BlockEvent": () => (/* binding */ BlockEvent),
/* harmony export */   "DeleteBlockEvent": () => (/* binding */ DeleteBlockEvent),
/* harmony export */   "PostBlockEvent": () => (/* binding */ PostBlockEvent),
/* harmony export */   "PutBlockEvent": () => (/* binding */ PutBlockEvent),
/* harmony export */   "default": () => (/* binding */ FMG_AxiosFilter)
/* harmony export */ });
/* harmony import */ var _shared_event_emitter__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(12);

class PutBlockEvent extends _shared_event_emitter__WEBPACK_IMPORTED_MODULE_0__.DataEvent {
    constructor(key, id) { super("put", { key, id }); }
}
class PostBlockEvent extends _shared_event_emitter__WEBPACK_IMPORTED_MODULE_0__.DataEvent {
    constructor(key, id) { super("post", { key, id }); }
}
class DeleteBlockEvent extends _shared_event_emitter__WEBPACK_IMPORTED_MODULE_0__.DataEvent {
    constructor(key, id) { super("delete", { key, id }); }
}
class BlockEvent extends _shared_event_emitter__WEBPACK_IMPORTED_MODULE_0__.DataEvent {
    constructor() { super("block"); }
}
function createBlockEvent(name, key, id) {
    switch (name) {
        case "put":
            return new PutBlockEvent(key, id);
        case "post":
            return new PostBlockEvent(key, id);
        case "delete":
            return new DeleteBlockEvent(key, id);
    }
}
const Filtred = Symbol("Filtred");
class FMG_AxiosFilter extends _shared_event_emitter__WEBPACK_IMPORTED_MODULE_0__["default"] {
    constructor(axios, handlers) {
        super();
        this.axios = axios;
        if (axios[Filtred])
            throw new Error("Axios is allready filtered!");
        this._createFilter("put", handlers.put);
        this._createFilter("post", handlers.post);
        this._createFilter("delete", handlers.delete);
    }
    _createFilter(name, requestHandlers) {
        const f = this.axios[name];
        this.axios[name] = (...args) => {
            return Promise.resolve().then(() => {
                var _a, _b;
                const [url, data] = args;
                const key = (_a = url.match(/\/api\/v1\/user\/((\/?[A-Za-z]+)+)\/?/)) === null || _a === void 0 ? void 0 : _a[1];
                const handler = key && requestHandlers[key.replace("/", "_")];
                if (handler) {
                    let id = parseInt(((_b = url.match(/(\d+)$/)) === null || _b === void 0 ? void 0 : _b[1]) || -1);
                    const result = handler.call(this, key, id, data, url);
                    this.emit(createBlockEvent(name, key, id));
                    this.emit(new BlockEvent());
                    return result;
                }
                return f.apply(this.axios, args);
            });
        };
    }
    on(name, f) { super.on(name, f); }
    ;
}


/***/ }),
/* 31 */
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (/* binding */ FMG_MapStorageFilter)
/* harmony export */ });
/* harmony import */ var _shared_filters_storage__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(32);
/* harmony import */ var _shared_key_toggle__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(21);


function getId(key) {
    var _a;
    return (_a = key.match(/(\d+)$/)) === null || _a === void 0 ? void 0 : _a[1];
}
const handleVisibleCategories = function (visible_categories, key, remove) {
    const id = getId(key);
    if (id) {
        (0,_shared_key_toggle__WEBPACK_IMPORTED_MODULE_1__["default"])(visible_categories, id, !remove);
    }
};
const RemoveHandler = {
    visible_categories(_, key) {
        var _a;
        handleVisibleCategories(((_a = this.manager.storage.data) === null || _a === void 0 ? void 0 : _a.visible_categories) || {}, key, true);
        return true;
    },
    remember_categories() {
        const storage = this.manager.storage;
        storage.autosave = false;
        if (storage.settings)
            storage.settings.remember_categories = false;
        if (storage.data)
            storage.data.visible_categories = {};
        storage.autosave = true;
        return true;
    }
};
const SetHandler = {
    visible_categories(_, key) {
        var _a;
        handleVisibleCategories(((_a = this.manager.storage.data) === null || _a === void 0 ? void 0 : _a.visible_categories) || {}, key, false);
        return true;
    },
    remember_categories() {
        const settings = this.manager.storage.settings;
        if (settings)
            settings.remember_categories = true;
        return true;
    }
};
class FMG_MapStorageFilter extends _shared_filters_storage__WEBPACK_IMPORTED_MODULE_0__["default"] {
    constructor(manager) {
        super(manager.window.localStorage, {
            set: SetHandler,
            remove: RemoveHandler
        });
        this.manager = manager;
    }
}


/***/ }),
/* 32 */
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (/* binding */ FMG_StorageFilter)
/* harmony export */ });
/* harmony import */ var _shared_event_emitter__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(12);

class SetBlockEvent extends _shared_event_emitter__WEBPACK_IMPORTED_MODULE_0__.DataEvent {
    constructor(key, value) { super("set", { key, value }); }
}
class RemoveBlockEvent extends _shared_event_emitter__WEBPACK_IMPORTED_MODULE_0__.DataEvent {
    constructor(key, value) { super("remove", { key, value }); }
}
function createBlockEvent(name, key, value) {
    switch (name) {
        case "setItem":
            return new SetBlockEvent(key, value);
        case "removeItem":
            return new RemoveBlockEvent(key, value);
    }
}
class FMG_StorageFilter extends _shared_event_emitter__WEBPACK_IMPORTED_MODULE_0__["default"] {
    constructor(local, handlers) {
        super();
        this.local = local;
        this._createFilter("setItem", handlers.set);
        this._createFilter("removeItem", handlers.remove);
    }
    _createFilter(name, handlers) {
        const f = Object.getPrototypeOf(this.local)[name];
        const filter = this;
        Object.getPrototypeOf(this.local)[name] = function (key, value) {
            // only execute this function if this object is our LocalStorage object
            if (this === filter.local) {
                for (const handlerName in handlers) {
                    if (key.match(handlerName)) {
                        const handler = handlers[handlerName];
                        const cancel = handler.call(filter, name, key, value);
                        filter.emit(createBlockEvent(name, key, value));
                        if (cancel)
                            return value;
                        break;
                    }
                }
            }
            return f.call(this, key, value);
        };
    }
    on(name, f) { super.on(name, f); }
    ;
}


/***/ }),
/* 33 */
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (/* export default binding */ __WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony default export */ function __WEBPACK_DEFAULT_EXPORT__(func, delay = 1000) {
    var handle;
    return function (...args) {
        if (handle)
            clearTimeout(handle);
        handle = setTimeout(() => {
            func.apply(null, args);
        }, delay);
    };
}


/***/ }),
/* 34 */
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "GuideUpdatedEvent": () => (/* binding */ GuideUpdatedEvent),
/* harmony export */   "default": () => (/* binding */ FMG_Guide)
/* harmony export */ });
/* harmony import */ var _shared_event_emitter__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(12);
/* harmony import */ var _shared_dataHandler__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(10);
/* harmony import */ var _filters_axios__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(35);
/* harmony import */ var _guide_manager_index__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(36);




class GuideUpdatedEvent extends _shared_event_emitter__WEBPACK_IMPORTED_MODULE_0__.DataEvent {
    constructor() { super("updated"); }
}
class FMG_Guide extends _shared_event_emitter__WEBPACK_IMPORTED_MODULE_0__["default"] {
    constructor(window) {
        super();
        this.guideManager = new _guide_manager_index__WEBPACK_IMPORTED_MODULE_3__["default"](window);
        this.axiosFilter = new _filters_axios__WEBPACK_IMPORTED_MODULE_2__["default"](this.guideManager);
        this.guideManager.on("load", (e) => {
            var _a;
            const map = (_a = e.data) === null || _a === void 0 ? void 0 : _a.map;
            if (map) {
                this.dataHandler = new _shared_dataHandler__WEBPACK_IMPORTED_MODULE_1__["default"](map.mapManager.window, this.guideManager.storage);
            }
        });
    }
    init() {
        this.guideManager.window.isPro = true;
        return this.guideManager.load();
    }
    reload() {
        this.guideManager.reload();
    }
    on(name, f) { super.on(name, f); }
}


/***/ }),
/* 35 */
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (/* binding */ FMG_GuideAxiosFilter)
/* harmony export */ });
/* harmony import */ var _shared_filters_axios__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(30);

const handleLocation = function (_, id) {
    var _a, _b;
    const isMarked = (_b = (_a = this.manager.storage.data) === null || _a === void 0 ? void 0 : _a.locations) === null || _b === void 0 ? void 0 : _b[id];
    this.manager.storage.markLocation(id, !isMarked);
};
const PutHandler = {
    locations: handleLocation
};
const DeleteHandler = {
    locations: handleLocation
};
class FMG_GuideAxiosFilter extends _shared_filters_axios__WEBPACK_IMPORTED_MODULE_0__["default"] {
    constructor(manager) {
        super(manager.window.axios, {
            put: PutHandler,
            post: {},
            delete: DeleteHandler
        });
        this.manager = manager;
    }
}


/***/ }),
/* 36 */
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "GuideManagerLoadEvent": () => (/* binding */ GuideManagerLoadEvent),
/* harmony export */   "default": () => (/* binding */ FMG_GuideManager)
/* harmony export */ });
/* harmony import */ var _shared_event_emitter__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(12);
/* harmony import */ var _map_index__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(9);
/* harmony import */ var _checkbox_manager_index__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(37);
/* harmony import */ var _storage__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(38);
var __awaiter = (undefined && undefined.__awaiter) || function (thisArg, _arguments, P, generator) {
    function adopt(value) { return value instanceof P ? value : new P(function (resolve) { resolve(value); }); }
    return new (P || (P = Promise))(function (resolve, reject) {
        function fulfilled(value) { try { step(generator.next(value)); } catch (e) { reject(e); } }
        function rejected(value) { try { step(generator["throw"](value)); } catch (e) { reject(e); } }
        function step(result) { result.done ? resolve(result.value) : adopt(result.value).then(fulfilled, rejected); }
        step((generator = generator.apply(thisArg, _arguments || [])).next());
    });
};




class GuideManagerLoadEvent extends _shared_event_emitter__WEBPACK_IMPORTED_MODULE_0__.DataEvent {
    constructor(map) { super("load", { map }); }
}
class FMG_GuideManager extends _shared_event_emitter__WEBPACK_IMPORTED_MODULE_0__["default"] {
    constructor(window) {
        super();
        this.window = window;
        this.document = window.document;
        this.storage = new _storage__WEBPACK_IMPORTED_MODULE_3__["default"]();
        this.checkboxManager = new _checkbox_manager_index__WEBPACK_IMPORTED_MODULE_2__["default"](this);
        $(this.document).find("iframe[src*='https://mapgenie.io']").on("load", () => this._setupMap());
    }
    _setupMap() {
        return __awaiter(this, void 0, void 0, function* () {
            return Promise.resolve()
                .then(() => __awaiter(this, void 0, void 0, function* () {
                var _a, _b;
                var i = 0;
                do {
                    this.mapWindow = this.window[i];
                    if (this.mapWindow)
                        break;
                    i++;
                } while (this.mapWindow);
                if (this.mapWindow) {
                    this.fmgMap = new _map_index__WEBPACK_IMPORTED_MODULE_1__["default"](this.mapWindow);
                    yield ((_a = this.fmgMap) === null || _a === void 0 ? void 0 : _a.ready());
                    this.storage.load(this.mapWindow);
                    this.emit(new GuideManagerLoadEvent(this.fmgMap));
                    (_b = this.fmgMap) === null || _b === void 0 ? void 0 : _b.on("updated", () => this.reload());
                }
                return this.fmgMap || null;
            }))
                .then(fmgMap => fmgMap === null || fmgMap === void 0 ? void 0 : fmgMap.init());
        });
    }
    reset() {
        this.checkboxManager.clear();
    }
    load() {
        this._setupMap()
            .then(() => this.reload());
    }
    reload() {
        this.reset();
        this.storage.reload();
        for (const id in this.storage.data.locations) {
            this.checkboxManager.markLocation(id, true);
        }
    }
    markLocation(id, found) {
        this.checkboxManager.markLocation(id, found);
    }
    on(name, f) { super.on(name, f); }
}


/***/ }),
/* 37 */
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "FMG_Checkbox": () => (/* binding */ FMG_Checkbox),
/* harmony export */   "default": () => (/* binding */ FMG_CheckboxManager)
/* harmony export */ });
class FMG_Checkbox {
    constructor(checkbox) {
        this._onCheckChanged = () => { };
        this.$checkbox = $(checkbox);
        this.mapId = this.$checkbox.data("map-id");
        this.locationsId = this.$checkbox.data("location-id");
        this.categoryId = this.$checkbox.data("category-id");
        this.regionId = this.$checkbox.data("region-id");
    }
    get checked() {
        return this.$checkbox.is(":checked");
    }
    set checked(b) {
        if (this.checked != b) {
            this.$checkbox.prop("checked", b);
            this._onCheckChanged(b);
        }
    }
    set onCheckChanged(f) {
        this._onCheckChanged = f.bind(this);
    }
    mark(found) {
        this.checked = found;
    }
}
class FMG_CheckboxManager {
    constructor(manager) {
        this._checkboxesByLocationId = {};
        this._checkboxesByCategories = {};
        $(manager.document).find("input[type='checkbox']").each((_, checkbox) => {
            const fmgCheckbox = new FMG_Checkbox(checkbox);
            this._checkboxesByLocationId[fmgCheckbox.locationsId] = fmgCheckbox;
            fmgCheckbox.onCheckChanged = function (checked) {
                var _a, _b;
                (_b = (_a = manager.window).markLocationFound) === null || _b === void 0 ? void 0 : _b.call(_a, {
                    target: checkbox
                }, this.locationsId, checked);
            };
            var byCategories = this._checkboxesByCategories[fmgCheckbox.categoryId];
            if (!byCategories) {
                byCategories = [];
                this._checkboxesByCategories[fmgCheckbox.categoryId] = byCategories;
            }
            byCategories.push(fmgCheckbox);
        });
    }
    markLocation(id, found) {
        const fmgCheckbox = this._checkboxesByLocationId[id];
        fmgCheckbox === null || fmgCheckbox === void 0 ? void 0 : fmgCheckbox.mark(found);
    }
    clear() {
        for (let id in this._checkboxesByLocationId) {
            const fmgCheckbox = this._checkboxesByLocationId[id];
            fmgCheckbox === null || fmgCheckbox === void 0 ? void 0 : fmgCheckbox.mark(false);
        }
    }
}


/***/ }),
/* 38 */
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (/* binding */ FMG_GuideStorage)
/* harmony export */ });
/* harmony import */ var _shared_storage_object__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(16);

class FMG_GuideStorage extends _shared_storage_object__WEBPACK_IMPORTED_MODULE_0__["default"] {
    constructor() {
        super();
    }
    markLocation(id, mark) {
        const locations = this.data.locations || {};
        if (mark) {
            locations[id] = true;
        }
        else {
            delete locations[id];
        }
    }
}


/***/ }),
/* 39 */
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (/* binding */ FMG_List)
/* harmony export */ });
/* harmony import */ var _list_manager__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(40);
/* harmony import */ var _ui_index__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(41);


class FMG_List {
    constructor(window) {
        this.listManager = new _list_manager__WEBPACK_IMPORTED_MODULE_0__["default"](window);
        this.ui = new _ui_index__WEBPACK_IMPORTED_MODULE_1__["default"](this.listManager);
    }
}


/***/ }),
/* 40 */
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (/* binding */ FMG_ListManager)
/* harmony export */ });
class FMG_ListManager {
    constructor(window) {
        this.window = window;
        this.document = window.document;
    }
}


/***/ }),
/* 41 */
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (/* binding */ FMG_ListUI)
/* harmony export */ });
/* harmony import */ var _search_bar__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(42);

class FMG_ListUI {
    constructor(listManager) {
        var _a;
        if ((_a = listManager.window.fmgSettings) === null || _a === void 0 ? void 0 : _a.custom_search_bar) {
            this.searchBar = new _search_bar__WEBPACK_IMPORTED_MODULE_0__["default"](listManager);
        }
    }
}


/***/ }),
/* 42 */
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (/* binding */ FMG_SearchBar)
/* harmony export */ });
/* harmony import */ var fuse_js__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(43);

const SCORE_EPSILON = 0.5;
class GameCard {
    constructor(card) {
        this.$element = $(card);
        this.title = this.$element.find(".card-body > h4").text();
    }
}
class FMG_SearchBar {
    constructor(manager) {
        this.$gameCards = $(manager.document).find("#games-list-container").find(".games").children();
        this._gameCards = [];
        this.$gameCards.each((_, card) => {
            const gameCard = new GameCard(card);
            this._gameCards.push(gameCard);
        });
        this._fuse = new fuse_js__WEBPACK_IMPORTED_MODULE_0__["default"](this._gameCards, {
            keys: ["title"],
            minMatchCharLength: 1,
            includeScore: false,
            shouldSort: false,
            includeMatches: false,
            threshold: 0,
            ignoreLocation: true,
        });
        this.$input = $(`<input id="game-search-input" list="games-list" type="search" placeholder="Search..." name="fmg:game_search">`)
            .insertBefore($(manager.document).find("#game-search-input").hide());
        this.$input.on("keyup", () => this._filterGameList(this.$input.val()));
    }
    _filterGameList(text) {
        const results = this._fuse.search(text);
        const ids = results.filter(result => {
            return (result.score || 0) <= SCORE_EPSILON;
        }).map(gameCard => gameCard.refIndex);
        this._gameCards.forEach((game, i) => {
            $(game.$element).toggle(text.length == 0 || ids.includes(i));
        });
    }
}


/***/ }),
/* 43 */
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (/* binding */ Fuse)
/* harmony export */ });
/**
 * Fuse.js v6.6.2 - Lightweight fuzzy-search (http://fusejs.io)
 *
 * Copyright (c) 2022 Kiro Risk (http://kiro.me)
 * All Rights Reserved. Apache Software License 2.0
 *
 * http://www.apache.org/licenses/LICENSE-2.0
 */

function isArray(value) {
  return !Array.isArray
    ? getTag(value) === '[object Array]'
    : Array.isArray(value)
}

// Adapted from: https://github.com/lodash/lodash/blob/master/.internal/baseToString.js
const INFINITY = 1 / 0;
function baseToString(value) {
  // Exit early for strings to avoid a performance hit in some environments.
  if (typeof value == 'string') {
    return value
  }
  let result = value + '';
  return result == '0' && 1 / value == -INFINITY ? '-0' : result
}

function toString(value) {
  return value == null ? '' : baseToString(value)
}

function isString(value) {
  return typeof value === 'string'
}

function isNumber(value) {
  return typeof value === 'number'
}

// Adapted from: https://github.com/lodash/lodash/blob/master/isBoolean.js
function isBoolean(value) {
  return (
    value === true ||
    value === false ||
    (isObjectLike(value) && getTag(value) == '[object Boolean]')
  )
}

function isObject(value) {
  return typeof value === 'object'
}

// Checks if `value` is object-like.
function isObjectLike(value) {
  return isObject(value) && value !== null
}

function isDefined(value) {
  return value !== undefined && value !== null
}

function isBlank(value) {
  return !value.trim().length
}

// Gets the `toStringTag` of `value`.
// Adapted from: https://github.com/lodash/lodash/blob/master/.internal/getTag.js
function getTag(value) {
  return value == null
    ? value === undefined
      ? '[object Undefined]'
      : '[object Null]'
    : Object.prototype.toString.call(value)
}

const EXTENDED_SEARCH_UNAVAILABLE = 'Extended search is not available';

const INCORRECT_INDEX_TYPE = "Incorrect 'index' type";

const LOGICAL_SEARCH_INVALID_QUERY_FOR_KEY = (key) =>
  `Invalid value for key ${key}`;

const PATTERN_LENGTH_TOO_LARGE = (max) =>
  `Pattern length exceeds max of ${max}.`;

const MISSING_KEY_PROPERTY = (name) => `Missing ${name} property in key`;

const INVALID_KEY_WEIGHT_VALUE = (key) =>
  `Property 'weight' in key '${key}' must be a positive integer`;

const hasOwn = Object.prototype.hasOwnProperty;

class KeyStore {
  constructor(keys) {
    this._keys = [];
    this._keyMap = {};

    let totalWeight = 0;

    keys.forEach((key) => {
      let obj = createKey(key);

      totalWeight += obj.weight;

      this._keys.push(obj);
      this._keyMap[obj.id] = obj;

      totalWeight += obj.weight;
    });

    // Normalize weights so that their sum is equal to 1
    this._keys.forEach((key) => {
      key.weight /= totalWeight;
    });
  }
  get(keyId) {
    return this._keyMap[keyId]
  }
  keys() {
    return this._keys
  }
  toJSON() {
    return JSON.stringify(this._keys)
  }
}

function createKey(key) {
  let path = null;
  let id = null;
  let src = null;
  let weight = 1;
  let getFn = null;

  if (isString(key) || isArray(key)) {
    src = key;
    path = createKeyPath(key);
    id = createKeyId(key);
  } else {
    if (!hasOwn.call(key, 'name')) {
      throw new Error(MISSING_KEY_PROPERTY('name'))
    }

    const name = key.name;
    src = name;

    if (hasOwn.call(key, 'weight')) {
      weight = key.weight;

      if (weight <= 0) {
        throw new Error(INVALID_KEY_WEIGHT_VALUE(name))
      }
    }

    path = createKeyPath(name);
    id = createKeyId(name);
    getFn = key.getFn;
  }

  return { path, id, weight, src, getFn }
}

function createKeyPath(key) {
  return isArray(key) ? key : key.split('.')
}

function createKeyId(key) {
  return isArray(key) ? key.join('.') : key
}

function get(obj, path) {
  let list = [];
  let arr = false;

  const deepGet = (obj, path, index) => {
    if (!isDefined(obj)) {
      return
    }
    if (!path[index]) {
      // If there's no path left, we've arrived at the object we care about.
      list.push(obj);
    } else {
      let key = path[index];

      const value = obj[key];

      if (!isDefined(value)) {
        return
      }

      // If we're at the last value in the path, and if it's a string/number/bool,
      // add it to the list
      if (
        index === path.length - 1 &&
        (isString(value) || isNumber(value) || isBoolean(value))
      ) {
        list.push(toString(value));
      } else if (isArray(value)) {
        arr = true;
        // Search each item in the array.
        for (let i = 0, len = value.length; i < len; i += 1) {
          deepGet(value[i], path, index + 1);
        }
      } else if (path.length) {
        // An object. Recurse further.
        deepGet(value, path, index + 1);
      }
    }
  };

  // Backwards compatibility (since path used to be a string)
  deepGet(obj, isString(path) ? path.split('.') : path, 0);

  return arr ? list : list[0]
}

const MatchOptions = {
  // Whether the matches should be included in the result set. When `true`, each record in the result
  // set will include the indices of the matched characters.
  // These can consequently be used for highlighting purposes.
  includeMatches: false,
  // When `true`, the matching function will continue to the end of a search pattern even if
  // a perfect match has already been located in the string.
  findAllMatches: false,
  // Minimum number of characters that must be matched before a result is considered a match
  minMatchCharLength: 1
};

const BasicOptions = {
  // When `true`, the algorithm continues searching to the end of the input even if a perfect
  // match is found before the end of the same input.
  isCaseSensitive: false,
  // When true, the matching function will continue to the end of a search pattern even if
  includeScore: false,
  // List of properties that will be searched. This also supports nested properties.
  keys: [],
  // Whether to sort the result list, by score
  shouldSort: true,
  // Default sort function: sort by ascending score, ascending index
  sortFn: (a, b) =>
    a.score === b.score ? (a.idx < b.idx ? -1 : 1) : a.score < b.score ? -1 : 1
};

const FuzzyOptions = {
  // Approximately where in the text is the pattern expected to be found?
  location: 0,
  // At what point does the match algorithm give up. A threshold of '0.0' requires a perfect match
  // (of both letters and location), a threshold of '1.0' would match anything.
  threshold: 0.6,
  // Determines how close the match must be to the fuzzy location (specified above).
  // An exact letter match which is 'distance' characters away from the fuzzy location
  // would score as a complete mismatch. A distance of '0' requires the match be at
  // the exact location specified, a threshold of '1000' would require a perfect match
  // to be within 800 characters of the fuzzy location to be found using a 0.8 threshold.
  distance: 100
};

const AdvancedOptions = {
  // When `true`, it enables the use of unix-like search commands
  useExtendedSearch: false,
  // The get function to use when fetching an object's properties.
  // The default will search nested paths *ie foo.bar.baz*
  getFn: get,
  // When `true`, search will ignore `location` and `distance`, so it won't matter
  // where in the string the pattern appears.
  // More info: https://fusejs.io/concepts/scoring-theory.html#fuzziness-score
  ignoreLocation: false,
  // When `true`, the calculation for the relevance score (used for sorting) will
  // ignore the field-length norm.
  // More info: https://fusejs.io/concepts/scoring-theory.html#field-length-norm
  ignoreFieldNorm: false,
  // The weight to determine how much field length norm effects scoring.
  fieldNormWeight: 1
};

var Config = {
  ...BasicOptions,
  ...MatchOptions,
  ...FuzzyOptions,
  ...AdvancedOptions
};

const SPACE = /[^ ]+/g;

// Field-length norm: the shorter the field, the higher the weight.
// Set to 3 decimals to reduce index size.
function norm(weight = 1, mantissa = 3) {
  const cache = new Map();
  const m = Math.pow(10, mantissa);

  return {
    get(value) {
      const numTokens = value.match(SPACE).length;

      if (cache.has(numTokens)) {
        return cache.get(numTokens)
      }

      // Default function is 1/sqrt(x), weight makes that variable
      const norm = 1 / Math.pow(numTokens, 0.5 * weight);

      // In place of `toFixed(mantissa)`, for faster computation
      const n = parseFloat(Math.round(norm * m) / m);

      cache.set(numTokens, n);

      return n
    },
    clear() {
      cache.clear();
    }
  }
}

class FuseIndex {
  constructor({
    getFn = Config.getFn,
    fieldNormWeight = Config.fieldNormWeight
  } = {}) {
    this.norm = norm(fieldNormWeight, 3);
    this.getFn = getFn;
    this.isCreated = false;

    this.setIndexRecords();
  }
  setSources(docs = []) {
    this.docs = docs;
  }
  setIndexRecords(records = []) {
    this.records = records;
  }
  setKeys(keys = []) {
    this.keys = keys;
    this._keysMap = {};
    keys.forEach((key, idx) => {
      this._keysMap[key.id] = idx;
    });
  }
  create() {
    if (this.isCreated || !this.docs.length) {
      return
    }

    this.isCreated = true;

    // List is Array<String>
    if (isString(this.docs[0])) {
      this.docs.forEach((doc, docIndex) => {
        this._addString(doc, docIndex);
      });
    } else {
      // List is Array<Object>
      this.docs.forEach((doc, docIndex) => {
        this._addObject(doc, docIndex);
      });
    }

    this.norm.clear();
  }
  // Adds a doc to the end of the index
  add(doc) {
    const idx = this.size();

    if (isString(doc)) {
      this._addString(doc, idx);
    } else {
      this._addObject(doc, idx);
    }
  }
  // Removes the doc at the specified index of the index
  removeAt(idx) {
    this.records.splice(idx, 1);

    // Change ref index of every subsquent doc
    for (let i = idx, len = this.size(); i < len; i += 1) {
      this.records[i].i -= 1;
    }
  }
  getValueForItemAtKeyId(item, keyId) {
    return item[this._keysMap[keyId]]
  }
  size() {
    return this.records.length
  }
  _addString(doc, docIndex) {
    if (!isDefined(doc) || isBlank(doc)) {
      return
    }

    let record = {
      v: doc,
      i: docIndex,
      n: this.norm.get(doc)
    };

    this.records.push(record);
  }
  _addObject(doc, docIndex) {
    let record = { i: docIndex, $: {} };

    // Iterate over every key (i.e, path), and fetch the value at that key
    this.keys.forEach((key, keyIndex) => {
      let value = key.getFn ? key.getFn(doc) : this.getFn(doc, key.path);

      if (!isDefined(value)) {
        return
      }

      if (isArray(value)) {
        let subRecords = [];
        const stack = [{ nestedArrIndex: -1, value }];

        while (stack.length) {
          const { nestedArrIndex, value } = stack.pop();

          if (!isDefined(value)) {
            continue
          }

          if (isString(value) && !isBlank(value)) {
            let subRecord = {
              v: value,
              i: nestedArrIndex,
              n: this.norm.get(value)
            };

            subRecords.push(subRecord);
          } else if (isArray(value)) {
            value.forEach((item, k) => {
              stack.push({
                nestedArrIndex: k,
                value: item
              });
            });
          } else ;
        }
        record.$[keyIndex] = subRecords;
      } else if (isString(value) && !isBlank(value)) {
        let subRecord = {
          v: value,
          n: this.norm.get(value)
        };

        record.$[keyIndex] = subRecord;
      }
    });

    this.records.push(record);
  }
  toJSON() {
    return {
      keys: this.keys,
      records: this.records
    }
  }
}

function createIndex(
  keys,
  docs,
  { getFn = Config.getFn, fieldNormWeight = Config.fieldNormWeight } = {}
) {
  const myIndex = new FuseIndex({ getFn, fieldNormWeight });
  myIndex.setKeys(keys.map(createKey));
  myIndex.setSources(docs);
  myIndex.create();
  return myIndex
}

function parseIndex(
  data,
  { getFn = Config.getFn, fieldNormWeight = Config.fieldNormWeight } = {}
) {
  const { keys, records } = data;
  const myIndex = new FuseIndex({ getFn, fieldNormWeight });
  myIndex.setKeys(keys);
  myIndex.setIndexRecords(records);
  return myIndex
}

function computeScore$1(
  pattern,
  {
    errors = 0,
    currentLocation = 0,
    expectedLocation = 0,
    distance = Config.distance,
    ignoreLocation = Config.ignoreLocation
  } = {}
) {
  const accuracy = errors / pattern.length;

  if (ignoreLocation) {
    return accuracy
  }

  const proximity = Math.abs(expectedLocation - currentLocation);

  if (!distance) {
    // Dodge divide by zero error.
    return proximity ? 1.0 : accuracy
  }

  return accuracy + proximity / distance
}

function convertMaskToIndices(
  matchmask = [],
  minMatchCharLength = Config.minMatchCharLength
) {
  let indices = [];
  let start = -1;
  let end = -1;
  let i = 0;

  for (let len = matchmask.length; i < len; i += 1) {
    let match = matchmask[i];
    if (match && start === -1) {
      start = i;
    } else if (!match && start !== -1) {
      end = i - 1;
      if (end - start + 1 >= minMatchCharLength) {
        indices.push([start, end]);
      }
      start = -1;
    }
  }

  // (i-1 - start) + 1 => i - start
  if (matchmask[i - 1] && i - start >= minMatchCharLength) {
    indices.push([start, i - 1]);
  }

  return indices
}

// Machine word size
const MAX_BITS = 32;

function search(
  text,
  pattern,
  patternAlphabet,
  {
    location = Config.location,
    distance = Config.distance,
    threshold = Config.threshold,
    findAllMatches = Config.findAllMatches,
    minMatchCharLength = Config.minMatchCharLength,
    includeMatches = Config.includeMatches,
    ignoreLocation = Config.ignoreLocation
  } = {}
) {
  if (pattern.length > MAX_BITS) {
    throw new Error(PATTERN_LENGTH_TOO_LARGE(MAX_BITS))
  }

  const patternLen = pattern.length;
  // Set starting location at beginning text and initialize the alphabet.
  const textLen = text.length;
  // Handle the case when location > text.length
  const expectedLocation = Math.max(0, Math.min(location, textLen));
  // Highest score beyond which we give up.
  let currentThreshold = threshold;
  // Is there a nearby exact match? (speedup)
  let bestLocation = expectedLocation;

  // Performance: only computer matches when the minMatchCharLength > 1
  // OR if `includeMatches` is true.
  const computeMatches = minMatchCharLength > 1 || includeMatches;
  // A mask of the matches, used for building the indices
  const matchMask = computeMatches ? Array(textLen) : [];

  let index;

  // Get all exact matches, here for speed up
  while ((index = text.indexOf(pattern, bestLocation)) > -1) {
    let score = computeScore$1(pattern, {
      currentLocation: index,
      expectedLocation,
      distance,
      ignoreLocation
    });

    currentThreshold = Math.min(score, currentThreshold);
    bestLocation = index + patternLen;

    if (computeMatches) {
      let i = 0;
      while (i < patternLen) {
        matchMask[index + i] = 1;
        i += 1;
      }
    }
  }

  // Reset the best location
  bestLocation = -1;

  let lastBitArr = [];
  let finalScore = 1;
  let binMax = patternLen + textLen;

  const mask = 1 << (patternLen - 1);

  for (let i = 0; i < patternLen; i += 1) {
    // Scan for the best match; each iteration allows for one more error.
    // Run a binary search to determine how far from the match location we can stray
    // at this error level.
    let binMin = 0;
    let binMid = binMax;

    while (binMin < binMid) {
      const score = computeScore$1(pattern, {
        errors: i,
        currentLocation: expectedLocation + binMid,
        expectedLocation,
        distance,
        ignoreLocation
      });

      if (score <= currentThreshold) {
        binMin = binMid;
      } else {
        binMax = binMid;
      }

      binMid = Math.floor((binMax - binMin) / 2 + binMin);
    }

    // Use the result from this iteration as the maximum for the next.
    binMax = binMid;

    let start = Math.max(1, expectedLocation - binMid + 1);
    let finish = findAllMatches
      ? textLen
      : Math.min(expectedLocation + binMid, textLen) + patternLen;

    // Initialize the bit array
    let bitArr = Array(finish + 2);

    bitArr[finish + 1] = (1 << i) - 1;

    for (let j = finish; j >= start; j -= 1) {
      let currentLocation = j - 1;
      let charMatch = patternAlphabet[text.charAt(currentLocation)];

      if (computeMatches) {
        // Speed up: quick bool to int conversion (i.e, `charMatch ? 1 : 0`)
        matchMask[currentLocation] = +!!charMatch;
      }

      // First pass: exact match
      bitArr[j] = ((bitArr[j + 1] << 1) | 1) & charMatch;

      // Subsequent passes: fuzzy match
      if (i) {
        bitArr[j] |=
          ((lastBitArr[j + 1] | lastBitArr[j]) << 1) | 1 | lastBitArr[j + 1];
      }

      if (bitArr[j] & mask) {
        finalScore = computeScore$1(pattern, {
          errors: i,
          currentLocation,
          expectedLocation,
          distance,
          ignoreLocation
        });

        // This match will almost certainly be better than any existing match.
        // But check anyway.
        if (finalScore <= currentThreshold) {
          // Indeed it is
          currentThreshold = finalScore;
          bestLocation = currentLocation;

          // Already passed `loc`, downhill from here on in.
          if (bestLocation <= expectedLocation) {
            break
          }

          // When passing `bestLocation`, don't exceed our current distance from `expectedLocation`.
          start = Math.max(1, 2 * expectedLocation - bestLocation);
        }
      }
    }

    // No hope for a (better) match at greater error levels.
    const score = computeScore$1(pattern, {
      errors: i + 1,
      currentLocation: expectedLocation,
      expectedLocation,
      distance,
      ignoreLocation
    });

    if (score > currentThreshold) {
      break
    }

    lastBitArr = bitArr;
  }

  const result = {
    isMatch: bestLocation >= 0,
    // Count exact matches (those with a score of 0) to be "almost" exact
    score: Math.max(0.001, finalScore)
  };

  if (computeMatches) {
    const indices = convertMaskToIndices(matchMask, minMatchCharLength);
    if (!indices.length) {
      result.isMatch = false;
    } else if (includeMatches) {
      result.indices = indices;
    }
  }

  return result
}

function createPatternAlphabet(pattern) {
  let mask = {};

  for (let i = 0, len = pattern.length; i < len; i += 1) {
    const char = pattern.charAt(i);
    mask[char] = (mask[char] || 0) | (1 << (len - i - 1));
  }

  return mask
}

class BitapSearch {
  constructor(
    pattern,
    {
      location = Config.location,
      threshold = Config.threshold,
      distance = Config.distance,
      includeMatches = Config.includeMatches,
      findAllMatches = Config.findAllMatches,
      minMatchCharLength = Config.minMatchCharLength,
      isCaseSensitive = Config.isCaseSensitive,
      ignoreLocation = Config.ignoreLocation
    } = {}
  ) {
    this.options = {
      location,
      threshold,
      distance,
      includeMatches,
      findAllMatches,
      minMatchCharLength,
      isCaseSensitive,
      ignoreLocation
    };

    this.pattern = isCaseSensitive ? pattern : pattern.toLowerCase();

    this.chunks = [];

    if (!this.pattern.length) {
      return
    }

    const addChunk = (pattern, startIndex) => {
      this.chunks.push({
        pattern,
        alphabet: createPatternAlphabet(pattern),
        startIndex
      });
    };

    const len = this.pattern.length;

    if (len > MAX_BITS) {
      let i = 0;
      const remainder = len % MAX_BITS;
      const end = len - remainder;

      while (i < end) {
        addChunk(this.pattern.substr(i, MAX_BITS), i);
        i += MAX_BITS;
      }

      if (remainder) {
        const startIndex = len - MAX_BITS;
        addChunk(this.pattern.substr(startIndex), startIndex);
      }
    } else {
      addChunk(this.pattern, 0);
    }
  }

  searchIn(text) {
    const { isCaseSensitive, includeMatches } = this.options;

    if (!isCaseSensitive) {
      text = text.toLowerCase();
    }

    // Exact match
    if (this.pattern === text) {
      let result = {
        isMatch: true,
        score: 0
      };

      if (includeMatches) {
        result.indices = [[0, text.length - 1]];
      }

      return result
    }

    // Otherwise, use Bitap algorithm
    const {
      location,
      distance,
      threshold,
      findAllMatches,
      minMatchCharLength,
      ignoreLocation
    } = this.options;

    let allIndices = [];
    let totalScore = 0;
    let hasMatches = false;

    this.chunks.forEach(({ pattern, alphabet, startIndex }) => {
      const { isMatch, score, indices } = search(text, pattern, alphabet, {
        location: location + startIndex,
        distance,
        threshold,
        findAllMatches,
        minMatchCharLength,
        includeMatches,
        ignoreLocation
      });

      if (isMatch) {
        hasMatches = true;
      }

      totalScore += score;

      if (isMatch && indices) {
        allIndices = [...allIndices, ...indices];
      }
    });

    let result = {
      isMatch: hasMatches,
      score: hasMatches ? totalScore / this.chunks.length : 1
    };

    if (hasMatches && includeMatches) {
      result.indices = allIndices;
    }

    return result
  }
}

class BaseMatch {
  constructor(pattern) {
    this.pattern = pattern;
  }
  static isMultiMatch(pattern) {
    return getMatch(pattern, this.multiRegex)
  }
  static isSingleMatch(pattern) {
    return getMatch(pattern, this.singleRegex)
  }
  search(/*text*/) {}
}

function getMatch(pattern, exp) {
  const matches = pattern.match(exp);
  return matches ? matches[1] : null
}

// Token: 'file

class ExactMatch extends BaseMatch {
  constructor(pattern) {
    super(pattern);
  }
  static get type() {
    return 'exact'
  }
  static get multiRegex() {
    return /^="(.*)"$/
  }
  static get singleRegex() {
    return /^=(.*)$/
  }
  search(text) {
    const isMatch = text === this.pattern;

    return {
      isMatch,
      score: isMatch ? 0 : 1,
      indices: [0, this.pattern.length - 1]
    }
  }
}

// Token: !fire

class InverseExactMatch extends BaseMatch {
  constructor(pattern) {
    super(pattern);
  }
  static get type() {
    return 'inverse-exact'
  }
  static get multiRegex() {
    return /^!"(.*)"$/
  }
  static get singleRegex() {
    return /^!(.*)$/
  }
  search(text) {
    const index = text.indexOf(this.pattern);
    const isMatch = index === -1;

    return {
      isMatch,
      score: isMatch ? 0 : 1,
      indices: [0, text.length - 1]
    }
  }
}

// Token: ^file

class PrefixExactMatch extends BaseMatch {
  constructor(pattern) {
    super(pattern);
  }
  static get type() {
    return 'prefix-exact'
  }
  static get multiRegex() {
    return /^\^"(.*)"$/
  }
  static get singleRegex() {
    return /^\^(.*)$/
  }
  search(text) {
    const isMatch = text.startsWith(this.pattern);

    return {
      isMatch,
      score: isMatch ? 0 : 1,
      indices: [0, this.pattern.length - 1]
    }
  }
}

// Token: !^fire

class InversePrefixExactMatch extends BaseMatch {
  constructor(pattern) {
    super(pattern);
  }
  static get type() {
    return 'inverse-prefix-exact'
  }
  static get multiRegex() {
    return /^!\^"(.*)"$/
  }
  static get singleRegex() {
    return /^!\^(.*)$/
  }
  search(text) {
    const isMatch = !text.startsWith(this.pattern);

    return {
      isMatch,
      score: isMatch ? 0 : 1,
      indices: [0, text.length - 1]
    }
  }
}

// Token: .file$

class SuffixExactMatch extends BaseMatch {
  constructor(pattern) {
    super(pattern);
  }
  static get type() {
    return 'suffix-exact'
  }
  static get multiRegex() {
    return /^"(.*)"\$$/
  }
  static get singleRegex() {
    return /^(.*)\$$/
  }
  search(text) {
    const isMatch = text.endsWith(this.pattern);

    return {
      isMatch,
      score: isMatch ? 0 : 1,
      indices: [text.length - this.pattern.length, text.length - 1]
    }
  }
}

// Token: !.file$

class InverseSuffixExactMatch extends BaseMatch {
  constructor(pattern) {
    super(pattern);
  }
  static get type() {
    return 'inverse-suffix-exact'
  }
  static get multiRegex() {
    return /^!"(.*)"\$$/
  }
  static get singleRegex() {
    return /^!(.*)\$$/
  }
  search(text) {
    const isMatch = !text.endsWith(this.pattern);
    return {
      isMatch,
      score: isMatch ? 0 : 1,
      indices: [0, text.length - 1]
    }
  }
}

class FuzzyMatch extends BaseMatch {
  constructor(
    pattern,
    {
      location = Config.location,
      threshold = Config.threshold,
      distance = Config.distance,
      includeMatches = Config.includeMatches,
      findAllMatches = Config.findAllMatches,
      minMatchCharLength = Config.minMatchCharLength,
      isCaseSensitive = Config.isCaseSensitive,
      ignoreLocation = Config.ignoreLocation
    } = {}
  ) {
    super(pattern);
    this._bitapSearch = new BitapSearch(pattern, {
      location,
      threshold,
      distance,
      includeMatches,
      findAllMatches,
      minMatchCharLength,
      isCaseSensitive,
      ignoreLocation
    });
  }
  static get type() {
    return 'fuzzy'
  }
  static get multiRegex() {
    return /^"(.*)"$/
  }
  static get singleRegex() {
    return /^(.*)$/
  }
  search(text) {
    return this._bitapSearch.searchIn(text)
  }
}

// Token: 'file

class IncludeMatch extends BaseMatch {
  constructor(pattern) {
    super(pattern);
  }
  static get type() {
    return 'include'
  }
  static get multiRegex() {
    return /^'"(.*)"$/
  }
  static get singleRegex() {
    return /^'(.*)$/
  }
  search(text) {
    let location = 0;
    let index;

    const indices = [];
    const patternLen = this.pattern.length;

    // Get all exact matches
    while ((index = text.indexOf(this.pattern, location)) > -1) {
      location = index + patternLen;
      indices.push([index, location - 1]);
    }

    const isMatch = !!indices.length;

    return {
      isMatch,
      score: isMatch ? 0 : 1,
      indices
    }
  }
}

// ❗Order is important. DO NOT CHANGE.
const searchers = [
  ExactMatch,
  IncludeMatch,
  PrefixExactMatch,
  InversePrefixExactMatch,
  InverseSuffixExactMatch,
  SuffixExactMatch,
  InverseExactMatch,
  FuzzyMatch
];

const searchersLen = searchers.length;

// Regex to split by spaces, but keep anything in quotes together
const SPACE_RE = / +(?=(?:[^\"]*\"[^\"]*\")*[^\"]*$)/;
const OR_TOKEN = '|';

// Return a 2D array representation of the query, for simpler parsing.
// Example:
// "^core go$ | rb$ | py$ xy$" => [["^core", "go$"], ["rb$"], ["py$", "xy$"]]
function parseQuery(pattern, options = {}) {
  return pattern.split(OR_TOKEN).map((item) => {
    let query = item
      .trim()
      .split(SPACE_RE)
      .filter((item) => item && !!item.trim());

    let results = [];
    for (let i = 0, len = query.length; i < len; i += 1) {
      const queryItem = query[i];

      // 1. Handle multiple query match (i.e, once that are quoted, like `"hello world"`)
      let found = false;
      let idx = -1;
      while (!found && ++idx < searchersLen) {
        const searcher = searchers[idx];
        let token = searcher.isMultiMatch(queryItem);
        if (token) {
          results.push(new searcher(token, options));
          found = true;
        }
      }

      if (found) {
        continue
      }

      // 2. Handle single query matches (i.e, once that are *not* quoted)
      idx = -1;
      while (++idx < searchersLen) {
        const searcher = searchers[idx];
        let token = searcher.isSingleMatch(queryItem);
        if (token) {
          results.push(new searcher(token, options));
          break
        }
      }
    }

    return results
  })
}

// These extended matchers can return an array of matches, as opposed
// to a singl match
const MultiMatchSet = new Set([FuzzyMatch.type, IncludeMatch.type]);

/**
 * Command-like searching
 * ======================
 *
 * Given multiple search terms delimited by spaces.e.g. `^jscript .python$ ruby !java`,
 * search in a given text.
 *
 * Search syntax:
 *
 * | Token       | Match type                 | Description                            |
 * | ----------- | -------------------------- | -------------------------------------- |
 * | `jscript`   | fuzzy-match                | Items that fuzzy match `jscript`       |
 * | `=scheme`   | exact-match                | Items that are `scheme`                |
 * | `'python`   | include-match              | Items that include `python`            |
 * | `!ruby`     | inverse-exact-match        | Items that do not include `ruby`       |
 * | `^java`     | prefix-exact-match         | Items that start with `java`           |
 * | `!^earlang` | inverse-prefix-exact-match | Items that do not start with `earlang` |
 * | `.js$`      | suffix-exact-match         | Items that end with `.js`              |
 * | `!.go$`     | inverse-suffix-exact-match | Items that do not end with `.go`       |
 *
 * A single pipe character acts as an OR operator. For example, the following
 * query matches entries that start with `core` and end with either`go`, `rb`,
 * or`py`.
 *
 * ```
 * ^core go$ | rb$ | py$
 * ```
 */
class ExtendedSearch {
  constructor(
    pattern,
    {
      isCaseSensitive = Config.isCaseSensitive,
      includeMatches = Config.includeMatches,
      minMatchCharLength = Config.minMatchCharLength,
      ignoreLocation = Config.ignoreLocation,
      findAllMatches = Config.findAllMatches,
      location = Config.location,
      threshold = Config.threshold,
      distance = Config.distance
    } = {}
  ) {
    this.query = null;
    this.options = {
      isCaseSensitive,
      includeMatches,
      minMatchCharLength,
      findAllMatches,
      ignoreLocation,
      location,
      threshold,
      distance
    };

    this.pattern = isCaseSensitive ? pattern : pattern.toLowerCase();
    this.query = parseQuery(this.pattern, this.options);
  }

  static condition(_, options) {
    return options.useExtendedSearch
  }

  searchIn(text) {
    const query = this.query;

    if (!query) {
      return {
        isMatch: false,
        score: 1
      }
    }

    const { includeMatches, isCaseSensitive } = this.options;

    text = isCaseSensitive ? text : text.toLowerCase();

    let numMatches = 0;
    let allIndices = [];
    let totalScore = 0;

    // ORs
    for (let i = 0, qLen = query.length; i < qLen; i += 1) {
      const searchers = query[i];

      // Reset indices
      allIndices.length = 0;
      numMatches = 0;

      // ANDs
      for (let j = 0, pLen = searchers.length; j < pLen; j += 1) {
        const searcher = searchers[j];
        const { isMatch, indices, score } = searcher.search(text);

        if (isMatch) {
          numMatches += 1;
          totalScore += score;
          if (includeMatches) {
            const type = searcher.constructor.type;
            if (MultiMatchSet.has(type)) {
              allIndices = [...allIndices, ...indices];
            } else {
              allIndices.push(indices);
            }
          }
        } else {
          totalScore = 0;
          numMatches = 0;
          allIndices.length = 0;
          break
        }
      }

      // OR condition, so if TRUE, return
      if (numMatches) {
        let result = {
          isMatch: true,
          score: totalScore / numMatches
        };

        if (includeMatches) {
          result.indices = allIndices;
        }

        return result
      }
    }

    // Nothing was matched
    return {
      isMatch: false,
      score: 1
    }
  }
}

const registeredSearchers = [];

function register(...args) {
  registeredSearchers.push(...args);
}

function createSearcher(pattern, options) {
  for (let i = 0, len = registeredSearchers.length; i < len; i += 1) {
    let searcherClass = registeredSearchers[i];
    if (searcherClass.condition(pattern, options)) {
      return new searcherClass(pattern, options)
    }
  }

  return new BitapSearch(pattern, options)
}

const LogicalOperator = {
  AND: '$and',
  OR: '$or'
};

const KeyType = {
  PATH: '$path',
  PATTERN: '$val'
};

const isExpression = (query) =>
  !!(query[LogicalOperator.AND] || query[LogicalOperator.OR]);

const isPath = (query) => !!query[KeyType.PATH];

const isLeaf = (query) =>
  !isArray(query) && isObject(query) && !isExpression(query);

const convertToExplicit = (query) => ({
  [LogicalOperator.AND]: Object.keys(query).map((key) => ({
    [key]: query[key]
  }))
});

// When `auto` is `true`, the parse function will infer and initialize and add
// the appropriate `Searcher` instance
function parse(query, options, { auto = true } = {}) {
  const next = (query) => {
    let keys = Object.keys(query);

    const isQueryPath = isPath(query);

    if (!isQueryPath && keys.length > 1 && !isExpression(query)) {
      return next(convertToExplicit(query))
    }

    if (isLeaf(query)) {
      const key = isQueryPath ? query[KeyType.PATH] : keys[0];

      const pattern = isQueryPath ? query[KeyType.PATTERN] : query[key];

      if (!isString(pattern)) {
        throw new Error(LOGICAL_SEARCH_INVALID_QUERY_FOR_KEY(key))
      }

      const obj = {
        keyId: createKeyId(key),
        pattern
      };

      if (auto) {
        obj.searcher = createSearcher(pattern, options);
      }

      return obj
    }

    let node = {
      children: [],
      operator: keys[0]
    };

    keys.forEach((key) => {
      const value = query[key];

      if (isArray(value)) {
        value.forEach((item) => {
          node.children.push(next(item));
        });
      }
    });

    return node
  };

  if (!isExpression(query)) {
    query = convertToExplicit(query);
  }

  return next(query)
}

// Practical scoring function
function computeScore(
  results,
  { ignoreFieldNorm = Config.ignoreFieldNorm }
) {
  results.forEach((result) => {
    let totalScore = 1;

    result.matches.forEach(({ key, norm, score }) => {
      const weight = key ? key.weight : null;

      totalScore *= Math.pow(
        score === 0 && weight ? Number.EPSILON : score,
        (weight || 1) * (ignoreFieldNorm ? 1 : norm)
      );
    });

    result.score = totalScore;
  });
}

function transformMatches(result, data) {
  const matches = result.matches;
  data.matches = [];

  if (!isDefined(matches)) {
    return
  }

  matches.forEach((match) => {
    if (!isDefined(match.indices) || !match.indices.length) {
      return
    }

    const { indices, value } = match;

    let obj = {
      indices,
      value
    };

    if (match.key) {
      obj.key = match.key.src;
    }

    if (match.idx > -1) {
      obj.refIndex = match.idx;
    }

    data.matches.push(obj);
  });
}

function transformScore(result, data) {
  data.score = result.score;
}

function format(
  results,
  docs,
  {
    includeMatches = Config.includeMatches,
    includeScore = Config.includeScore
  } = {}
) {
  const transformers = [];

  if (includeMatches) transformers.push(transformMatches);
  if (includeScore) transformers.push(transformScore);

  return results.map((result) => {
    const { idx } = result;

    const data = {
      item: docs[idx],
      refIndex: idx
    };

    if (transformers.length) {
      transformers.forEach((transformer) => {
        transformer(result, data);
      });
    }

    return data
  })
}

class Fuse {
  constructor(docs, options = {}, index) {
    this.options = { ...Config, ...options };

    if (
      this.options.useExtendedSearch &&
      !true
    ) {}

    this._keyStore = new KeyStore(this.options.keys);

    this.setCollection(docs, index);
  }

  setCollection(docs, index) {
    this._docs = docs;

    if (index && !(index instanceof FuseIndex)) {
      throw new Error(INCORRECT_INDEX_TYPE)
    }

    this._myIndex =
      index ||
      createIndex(this.options.keys, this._docs, {
        getFn: this.options.getFn,
        fieldNormWeight: this.options.fieldNormWeight
      });
  }

  add(doc) {
    if (!isDefined(doc)) {
      return
    }

    this._docs.push(doc);
    this._myIndex.add(doc);
  }

  remove(predicate = (/* doc, idx */) => false) {
    const results = [];

    for (let i = 0, len = this._docs.length; i < len; i += 1) {
      const doc = this._docs[i];
      if (predicate(doc, i)) {
        this.removeAt(i);
        i -= 1;
        len -= 1;

        results.push(doc);
      }
    }

    return results
  }

  removeAt(idx) {
    this._docs.splice(idx, 1);
    this._myIndex.removeAt(idx);
  }

  getIndex() {
    return this._myIndex
  }

  search(query, { limit = -1 } = {}) {
    const {
      includeMatches,
      includeScore,
      shouldSort,
      sortFn,
      ignoreFieldNorm
    } = this.options;

    let results = isString(query)
      ? isString(this._docs[0])
        ? this._searchStringList(query)
        : this._searchObjectList(query)
      : this._searchLogical(query);

    computeScore(results, { ignoreFieldNorm });

    if (shouldSort) {
      results.sort(sortFn);
    }

    if (isNumber(limit) && limit > -1) {
      results = results.slice(0, limit);
    }

    return format(results, this._docs, {
      includeMatches,
      includeScore
    })
  }

  _searchStringList(query) {
    const searcher = createSearcher(query, this.options);
    const { records } = this._myIndex;
    const results = [];

    // Iterate over every string in the index
    records.forEach(({ v: text, i: idx, n: norm }) => {
      if (!isDefined(text)) {
        return
      }

      const { isMatch, score, indices } = searcher.searchIn(text);

      if (isMatch) {
        results.push({
          item: text,
          idx,
          matches: [{ score, value: text, norm, indices }]
        });
      }
    });

    return results
  }

  _searchLogical(query) {

    const expression = parse(query, this.options);

    const evaluate = (node, item, idx) => {
      if (!node.children) {
        const { keyId, searcher } = node;

        const matches = this._findMatches({
          key: this._keyStore.get(keyId),
          value: this._myIndex.getValueForItemAtKeyId(item, keyId),
          searcher
        });

        if (matches && matches.length) {
          return [
            {
              idx,
              item,
              matches
            }
          ]
        }

        return []
      }

      const res = [];
      for (let i = 0, len = node.children.length; i < len; i += 1) {
        const child = node.children[i];
        const result = evaluate(child, item, idx);
        if (result.length) {
          res.push(...result);
        } else if (node.operator === LogicalOperator.AND) {
          return []
        }
      }
      return res
    };

    const records = this._myIndex.records;
    const resultMap = {};
    const results = [];

    records.forEach(({ $: item, i: idx }) => {
      if (isDefined(item)) {
        let expResults = evaluate(expression, item, idx);

        if (expResults.length) {
          // Dedupe when adding
          if (!resultMap[idx]) {
            resultMap[idx] = { idx, item, matches: [] };
            results.push(resultMap[idx]);
          }
          expResults.forEach(({ matches }) => {
            resultMap[idx].matches.push(...matches);
          });
        }
      }
    });

    return results
  }

  _searchObjectList(query) {
    const searcher = createSearcher(query, this.options);
    const { keys, records } = this._myIndex;
    const results = [];

    // List is Array<Object>
    records.forEach(({ $: item, i: idx }) => {
      if (!isDefined(item)) {
        return
      }

      let matches = [];

      // Iterate over every key (i.e, path), and fetch the value at that key
      keys.forEach((key, keyIndex) => {
        matches.push(
          ...this._findMatches({
            key,
            value: item[keyIndex],
            searcher
          })
        );
      });

      if (matches.length) {
        results.push({
          idx,
          item,
          matches
        });
      }
    });

    return results
  }
  _findMatches({ key, value, searcher }) {
    if (!isDefined(value)) {
      return []
    }

    let matches = [];

    if (isArray(value)) {
      value.forEach(({ v: text, i: idx, n: norm }) => {
        if (!isDefined(text)) {
          return
        }

        const { isMatch, score, indices } = searcher.searchIn(text);

        if (isMatch) {
          matches.push({
            score,
            key,
            value: text,
            idx,
            norm,
            indices
          });
        }
      });
    } else {
      const { v: text, n: norm } = value;

      const { isMatch, score, indices } = searcher.searchIn(text);

      if (isMatch) {
        matches.push({ score, key, value: text, norm, indices });
      }
    }

    return matches
  }
}

Fuse.version = '6.6.2';
Fuse.createIndex = createIndex;
Fuse.parseIndex = parseIndex;
Fuse.config = Config;

{
  Fuse.parseQuery = parse;
}

{
  register(ExtendedSearch);
}




/***/ }),
/* 44 */
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (/* export default binding */ __WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony default export */ function __WEBPACK_DEFAULT_EXPORT__(style) {
    const element = document.createElement("style");
    element.innerHTML = style;
    document.head.appendChild(element);
}


/***/ })
/******/ 	]);
/************************************************************************/
/******/ 	// The module cache
/******/ 	var __webpack_module_cache__ = {};
/******/ 	
/******/ 	// The require function
/******/ 	function __webpack_require__(moduleId) {
/******/ 		// Check if module is in cache
/******/ 		var cachedModule = __webpack_module_cache__[moduleId];
/******/ 		if (cachedModule !== undefined) {
/******/ 			return cachedModule.exports;
/******/ 		}
/******/ 		// Create a new module (and put it into the cache)
/******/ 		var module = __webpack_module_cache__[moduleId] = {
/******/ 			// no module.id needed
/******/ 			// no module.loaded needed
/******/ 			exports: {}
/******/ 		};
/******/ 	
/******/ 		// Execute the module function
/******/ 		__webpack_modules__[moduleId](module, module.exports, __webpack_require__);
/******/ 	
/******/ 		// Return the exports of the module
/******/ 		return module.exports;
/******/ 	}
/******/ 	
/************************************************************************/
/******/ 	/* webpack/runtime/define property getters */
/******/ 	(() => {
/******/ 		// define getter functions for harmony exports
/******/ 		__webpack_require__.d = (exports, definition) => {
/******/ 			for(var key in definition) {
/******/ 				if(__webpack_require__.o(definition, key) && !__webpack_require__.o(exports, key)) {
/******/ 					Object.defineProperty(exports, key, { enumerable: true, get: definition[key] });
/******/ 				}
/******/ 			}
/******/ 		};
/******/ 	})();
/******/ 	
/******/ 	/* webpack/runtime/hasOwnProperty shorthand */
/******/ 	(() => {
/******/ 		__webpack_require__.o = (obj, prop) => (Object.prototype.hasOwnProperty.call(obj, prop))
/******/ 	})();
/******/ 	
/******/ 	/* webpack/runtime/make namespace object */
/******/ 	(() => {
/******/ 		// define __esModule on exports
/******/ 		__webpack_require__.r = (exports) => {
/******/ 			if(typeof Symbol !== 'undefined' && Symbol.toStringTag) {
/******/ 				Object.defineProperty(exports, Symbol.toStringTag, { value: 'Module' });
/******/ 			}
/******/ 			Object.defineProperty(exports, '__esModule', { value: true });
/******/ 		};
/******/ 	})();
/******/ 	
/************************************************************************/
var __webpack_exports__ = {};
// This entry need to be wrapped in an IIFE because it need to be isolated against other modules in the chunk.
(() => {
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _site__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(5);
/* harmony import */ var _css_list_css__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(7);
/* harmony import */ var _css_map_css__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(8);
/* harmony import */ var _map_index__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(9);
/* harmony import */ var _guide_index__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(34);
/* harmony import */ var _list_index__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(39);
/* harmony import */ var _shared_appendStyle__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(44);
/* harmony import */ var _shared_load_utils__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(6);
var __awaiter = (undefined && undefined.__awaiter) || function (thisArg, _arguments, P, generator) {
    function adopt(value) { return value instanceof P ? value : new P(function (resolve) { resolve(value); }); }
    return new (P || (P = Promise))(function (resolve, reject) {
        function fulfilled(value) { try { step(generator.next(value)); } catch (e) { reject(e); } }
        function rejected(value) { try { step(generator["throw"](value)); } catch (e) { reject(e); } }
        function step(result) { result.done ? resolve(result.value) : adopt(result.value).then(fulfilled, rejected); }
        step((generator = generator.apply(thisArg, _arguments || [])).next());
    });
};








function reloadListeners(reloadCb) {
    document.addEventListener("visibilitychange", () => {
        switch (document.visibilityState) {
            case "visible":
                reloadCb();
                break;
        }
    });
    window.addEventListener("message", (e) => {
        switch (e.data.type) {
            case "reload":
            case "fmg:update":
                reloadCb();
                break;
        }
    });
}
(function () {
    return __awaiter(this, void 0, void 0, function* () {
        const session = window.sessionStorage;
        const settings = JSON.parse(session.getItem("fmg:extension:settings") || "{}");
        const debug = JSON.parse(session.getItem("fmg:debug_mode") || "false");
        window.fmgSettings = settings;
        window.fmgDebug = debug;
        const config = window.config || {};
        config.presetsEnabled = config.presetsEnabled || (settings === null || settings === void 0 ? void 0 : settings.presets_allways_enabled) || false;
        switch (yield (0,_site__WEBPACK_IMPORTED_MODULE_0__["default"])()) {
            case "map":
                (0,_shared_appendStyle__WEBPACK_IMPORTED_MODULE_6__["default"])(_css_map_css__WEBPACK_IMPORTED_MODULE_2__["default"]);
                // only if user is loggedin
                if (!!window.user) {
                    yield (0,_shared_load_utils__WEBPACK_IMPORTED_MODULE_7__.waitForGlobalsLoaded)(["store"]);
                    const map = new _map_index__WEBPACK_IMPORTED_MODULE_3__["default"](window);
                    map.init();
                    reloadListeners(() => map.reload());
                    window.fmgMap = window.fmgDebug ? undefined : map;
                }
                break;
            case "guide":
                yield (0,_shared_load_utils__WEBPACK_IMPORTED_MODULE_7__.waitForGlobalsLoaded)(["foundLocations"]);
                const guide = new _guide_index__WEBPACK_IMPORTED_MODULE_4__["default"](window);
                guide.init();
                reloadListeners(() => guide.reload());
                window.fmgGuide = window.fmgDebug ? undefined : guide;
                break;
            case "list":
                (0,_shared_appendStyle__WEBPACK_IMPORTED_MODULE_6__["default"])(_css_list_css__WEBPACK_IMPORTED_MODULE_1__["default"]);
                yield (0,_shared_load_utils__WEBPACK_IMPORTED_MODULE_7__.waitForGlobalsLoaded)(["List"]);
                const list = new _list_index__WEBPACK_IMPORTED_MODULE_5__["default"](window);
                window.fmgList = window.fmgDebug ? undefined : list;
                break;
            default:
                return;
        }
        (0,_shared_load_utils__WEBPACK_IMPORTED_MODULE_7__.waitForDomLoaded)().then(() => {
            //Hide non-pro elements
            $([
                "#blobby-left", ".upgrade", ".progress-buttons ~ .inset",
                "#button-upgrade", "p ~ h5 ~ p ~ h4 ~ blockquote", "p ~ h5 ~ p ~ h4" // guide
            ].join(",")).hide();
        });
    });
})();
window.addEventListener("message", (e) => {
    switch (e.data.type) {
        case "mg:error":
            window.toastr.error(e.data.message);
            break;
    }
});

})();

/******/ })()
;